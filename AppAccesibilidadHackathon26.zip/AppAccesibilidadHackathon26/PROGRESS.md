# Progreso de la app (PoC)

**Última actualización:** 2026-03-24 — **Mock Simplify This (noticia por URL):** `SimplifyNewsFromURLMockView.swift` — vista solo en Preview (no `AppRootView`); enlace o simulación de documento, espera 3 s y lectura simplificada hardcodeada (tema IA en la UE).

**Anterior:** Sesión **Agendar cita**: formulario denso a pantalla completa + **burbuja de asistente** (minimizar/expandir), **11 pasos** con scroll automático al ancla del mock, TTS con **silenciar / más rápido / auto-habla al paso**, **Modo foco** en la burbuja; **Simplificar** solo en **Más opciones** (vista alternativa o mock claro in situ). Estado del formulario simulado evoluciona con el paso hasta banner de éxito.

## Mapa de flujo (implementado)

```mermaid
flowchart LR
    A[AppRootView] --> B[SplashEntryView]
    B -->|Primera vez| C[WelcomeView]
    B -->|Ya completó flujo| G[ContentView]
    C -->|Personalizar ahora| D[OnboardingFlowView]
    C -->|Explorar primero| G
    D --> E[DifficultiesSelectionView]
    E -->|Continuar push| F[InteractionStyleView]
    F -->|Continuar push| H[DemoModeActivationView]
    H -->|Ver mi experiencia| I[ProfileSummaryView]
    I -->|Ir al inicio| G
    G -->|Ajustes o personalizar| D
    G -->|Guíame| S7[GuidedSessionStartView]
    G -->|Simplificar| S10[SimplifiedTaskView]
    G -->|Modo foco| P[HomeModePlaceholderView]
    G -->|Perfil| Q[Sheet resumen ayudas]
    S7 -->|Continuar demo| S9[GuidedSessionLiveView]
    S9 -->|Más opciones: vista simplificada| S10
```

- **Entrada:** `AppAccesibilidadHackathon26App` → `AppRootView`.
- **Estado:** `AppFlowPhase` en `AppRootView` (`splash` → `welcome` o `home` si `hasCompletedFirstFlow`).
- **Persistencia (simple):** `@AppStorage` `hasCompletedFirstFlow` y `homeEntryPersonalization` — tras la primera llegada a inicio se recuerda el modo; al relanzar, splash → inicio directo.
- **Modos demo (PoC):** al terminar el resumen se guardan `demoGuideMeEnabled`, `demoFocusEnabled`, `demoSimplifyEnabled` según `DemoSupportMode` en pantalla 4.
- **Onboarding:** `NavigationStack` con push dificultades → estilo → ayudas → resumen (botón atrás del sistema en los pasos empujados).
- **Guíame:** `HomeRoute.guidedSession` → `GuidedSessionStartView` (pantalla 7). `HomeRoute.guidedAppointmentDemo` → `GuidedSessionLiveView` (pantalla 9): **barra de navegador simulada** + **mismo mock** + overlay de burbuja; `ScrollViewReader` + `AppointmentMockScrollAnchor` en `AppointmentBookingDenseMockView`. `pathForSimplifiedLink: $path` empuja `HomeRoute.simplify(fromGuidedSession: true)` desde el menú **Más opciones** (si Simplificar está activo en personalización).
- **Simplificar (home):** tarjeta con `demoSimplifyEnabled` → `simplify(fromGuidedSession: false)`. **Salir** en pantalla 10 vuelve atrás en el stack; desde sesión guiada vuelve a pantalla 9.
- **Previews desacoplados (capturas / demos):** `MessyMapsAppScreenshotView`, `MessyPortalFormScreenshotView`, `SimplifyNewsFromURLMockView` — no forman parte del grafo `AppRootView`; abrir su `#Preview` en Xcode.

## Hitos

| # | Hito | Estado | Archivos / notas |
|---|------|--------|------------------|
| 1 | Paleta y tokens semánticos | Hecho | `AppPalette.swift`, `Assets.xcassets` (`app*` incl. `appAccent` + `AccentColor`) |
| 2 | Splash de marca | Hecho | `SplashEntryView.swift` — CTA "Comenzar", auto-avance, un solo `onContinue` |
| 3 | Bienvenida (personalizar vs explorar) | Hecho | `WelcomeView.swift` |
| 4 | Raíz splash → home + reentrada | Hecho | `AppRootView.swift`, `@AppStorage`, animación suave entre fases |
| 5 | Onboarding — selección de dificultades | Hecho | `DifficultiesSelectionView.swift`, `OnboardingModels.swift`, `SelectableCardView.swift` |
| 6 | Onboarding — estilo de interacción | Hecho | `InteractionStyleView.swift`, `OnboardingFlowView.swift` + `NavigationStack` |
| 6b | Onboarding — ayudas demo + resumen | Hecho | `DemoModeActivationView.swift` (`LargeModeToggleCard`), `ProfileSummaryView.swift`, `DemoSupportMode` en `OnboardingModels.swift` |
| 7 | Pantalla de inicio con 3 modos | Hecho | `ContentView.swift`, `HomeModePlaceholderViews.swift` (`HomeRoute`), `DemoSupportMode.homeCardSubtitle` en `OnboardingModels.swift` |
| 7b | Inicio sesión guiada (pantalla 7) | Hecho | `GuidedSessionStartView.swift` — título, copy, opciones, CTA; `HomeRoute.guidedAppointmentDemo` |
| 8 | Guide Me — sesión "agendar cita" | Hecho | `GuidedSessionLiveView.swift`, `GuidedSessionSteps.swift`, `AppointmentBookingMockViews.swift` — **11 pasos**, burbuja, scroll+foco, `AppointmentMockFormState`, TTS `GuidedSpeechController` (`ObservableObject`) |
| 9 | Focus y Simplify en contexto | Hecho | Foco en burbuja; Simplificar en **Más opciones** + toggle mock claro in situ; Pantalla 10 enlazada desde sesión y home |
| 10 | Versión simplificada (segunda interfaz) | Hecho | `SimplifiedTaskView.swift` — narrativa aparte; `GuidedSpeechController` vía `@StateObject` |
| 10b | Simplify This — noticia/blog por URL (mock, Preview) | Hecho | `SimplifyNewsFromURLMockView.swift` — burbuja asistente + `GuidedSpeechController` (Escuchar / Silenciar / velocidad), pasos de explicación en resultado, foco visual por sección, cabecera y metadatos; sin `AppRootView` |

## Siguiente paso

**Modo foco desde home** — Sustituir placeholder `HomeRoute.focusMode` por una experiencia mínima alineada con el tono de la burbuja y el mock denso.

## Conexión con la narrativa (Elena)

Flujo **Guíame** → **mismo portal feo** con asistente encima (voz + pasos + desplazamiento), sin que la narrativa principal dependa de una segunda interfaz. **Simplificar** queda como recurso opcional si la pantalla abruma. Ver `.cursor/rules/proyecto-accesibilidad-adaptativa.mdc`.
