//
//  AppAccesibilidadHackathon26Tests.swift
//  AppAccesibilidadHackathon26Tests
//
//  Created by Kevin on 23/03/26.
//

import Testing
@testable import AppAccesibilidadHackathon26

struct AppAccesibilidadHackathon26Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
