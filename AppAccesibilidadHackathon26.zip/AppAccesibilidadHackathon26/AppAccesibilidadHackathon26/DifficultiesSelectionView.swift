//
//  DifficultiesSelectionView.swift
//  AppAccesibilidadHackathon26
//

import SwiftUI

struct DifficultiesSelectionView: View {
    @Binding var selectedDifficulties: Set<AccessibilityDifficulty>
    let onContinue: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("¿Qué suele dificultarte usar otras apps?")
                        .font(.title.bold())
                        .foregroundStyle(AppPalette.textPrimary)
                        .fixedSize(horizontal: false, vertical: true)
                        .accessibilityAddTraits(.isHeader)

                    Text("Selecciona todo lo que aplique. Esto nos ayuda a adaptar la experiencia.")
                        .font(.body)
                        .foregroundStyle(AppPalette.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .lineSpacing(4)
                }

                VStack(spacing: 12) {
                    ForEach(AccessibilityDifficulty.allCases) { difficulty in
                        SelectableCardView(
                            icon: difficulty.icon,
                            label: difficulty.displayLabel,
                            isSelected: selectedDifficulties.contains(difficulty)
                        ) {
                            toggleDifficulty(difficulty)
                        }
                    }
                }
            }
            .padding(.horizontal, 24)
            .padding(.top, 32)
            .padding(.bottom, 24)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            VStack(spacing: 12) {
                Text("Puedes cambiar esto después")
                    .font(.footnote)
                    .foregroundStyle(AppPalette.textSecondary)

                Button(action: onContinue) {
                    Text("Continuar")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                }
                .buttonStyle(.borderedProminent)
                .tint(AppPalette.primary)
                .foregroundStyle(AppPalette.primaryOnPrimary)
                .accessibilityHint("Avanza al siguiente paso de personalización")
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 16)
            .background(AppPalette.canvas)
        }
        .background(AppPalette.canvas)
    }

    private func toggleDifficulty(_ difficulty: AccessibilityDifficulty) {
        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
            if selectedDifficulties.contains(difficulty) {
                selectedDifficulties.remove(difficulty)
            } else {
                selectedDifficulties.insert(difficulty)
            }
        }
    }
}

#Preview {
    DifficultiesSelectionView(
        selectedDifficulties: .constant(AccessibilityDifficulty.elenaDefaults),
        onContinue: {}
    )
}
