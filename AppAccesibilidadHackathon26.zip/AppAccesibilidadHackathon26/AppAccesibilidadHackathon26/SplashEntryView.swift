//
//  SplashEntryView.swift
//  AppAccesibilidadHackathon26
//

import SwiftUI

private enum ProductBranding {
    static let displayName = "Guía Clara"
    static let tagline = "Guía accesible, un paso a la vez."
}

struct SplashEntryView: View {
    let onContinue: () -> Void

    @State private var brandingAppeared = false
    @State private var didContinue = false

    private static let autoAdvanceSeconds: Duration = .seconds(2.5)

    var body: some View {
        VStack(spacing: 24) {
            Spacer(minLength: 0)

            VStack(spacing: 16) {
                Image(systemName: "signpost.right.circle.fill")
                    .font(.system(size: 56))
                    .foregroundStyle(AppPalette.primary)
                    .accessibilityHidden(true)

                Text(ProductBranding.displayName)
                    .font(.largeTitle.bold())
                    .foregroundStyle(AppPalette.textPrimary)
                    .multilineTextAlignment(.center)
                    .accessibilityAddTraits(.isHeader)

                Text(ProductBranding.tagline)
                    .font(.title3)
                    .foregroundStyle(AppPalette.textSecondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 8)
            }
            .opacity(brandingAppeared ? 1 : 0)
            .scaleEffect(brandingAppeared ? 1 : 0.96)
            .animation(.easeOut(duration: 0.85), value: brandingAppeared)
            .accessibilityElement(children: .combine)
            .accessibilityLabel(
                "\(ProductBranding.displayName). \(ProductBranding.tagline)"
            )

            Spacer(minLength: 0)

            Button {
                completeSplash()
            } label: {
                Text("Comenzar")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
            }
            .buttonStyle(.borderedProminent)
            .tint(AppPalette.primary)
            .foregroundStyle(AppPalette.primaryOnPrimary)
            .padding(.horizontal, 24)
            .padding(.bottom, 8)
            .accessibilityHint(
                "Continúa a la bienvenida la primera vez, o al inicio si ya configuraste antes"
            )
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(AppPalette.canvas)
        .onAppear {
            brandingAppeared = true
        }
        .task {
            try? await Task.sleep(for: Self.autoAdvanceSeconds)
            completeSplash()
        }
    }

    private func completeSplash() {
        guard !didContinue else { return }
        didContinue = true
        onContinue()
    }
}

#Preview {
    AppRootView()
}
