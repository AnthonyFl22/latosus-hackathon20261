//
//  GuidedSessionSteps.swift
//  AppAccesibilidadHackathon26
//

import Foundation

/// Scroll targets inside the dense mock (`ScrollViewReader`).
enum AppointmentMockScrollAnchor: String, CaseIterable, Hashable {
    case topClutter
    case centerField
    case specialtyField
    case dateRow
    case timeSlots
    case nameField
    case phoneField
    case smsToggle
    case confirmationSummary
    case confirmButton
    case successBanner
}

/// Which block of the dense appointment mock should be visually emphasized (focus mode + step).
enum AppointmentMockFocusSection: Int, CaseIterable, Hashable {
    case topClutter = 0
    case serviceAndSpecialty = 1
    case dateAndSlot = 2
    case patientDetails = 3
    case confirmation = 4
}

struct GuidedSessionStep: Identifiable, Hashable {
    let id: Int
    /// Short context for the assistant bubble.
    let screenSummary: String
    /// Recommended action for the user.
    let recommendedNextStep: String
    /// Spoken script for TTS (Spanish).
    let voiceScript: String
    /// Mock region to highlight when focus mode is on.
    let focusSection: AppointmentMockFocusSection
    let scrollAnchor: AppointmentMockScrollAnchor

    static let appointmentDemo: [GuidedSessionStep] = [
        GuidedSessionStep(
            id: 0,
            screenSummary: "Es el portal real de la clínica: avisos legales, anuncios y un formulario largo debajo.",
            recommendedNextStep: "No hace falta leerlo todo ahora. Bajaremos al formulario paso a paso.",
            voiceScript:
                "Esta pantalla es la web de la clínica. Arriba hay avisos y ofertas; puede marear un poco. No te preocupes: yo te iré diciendo qué tocar en el formulario de abajo.",
            focusSection: .topClutter,
            scrollAnchor: .topClutter
        ),
        GuidedSessionStep(
            id: 1,
            screenSummary: "El formulario empieza pidiendo el centro donde quieres la cita.",
            recommendedNextStep: "Abre el desplegable de centro y elige el que te corresponda.",
            voiceScript:
                "Primero, el centro. Busca el recuadro de centro y elige uno, por ejemplo Centro Sur si es el tuyo.",
            focusSection: .serviceAndSpecialty,
            scrollAnchor: .centerField
        ),
        GuidedSessionStep(
            id: 2,
            screenSummary: "Ahora toca la especialidad o el tipo de consulta.",
            recommendedNextStep: "Selecciona la especialidad, por ejemplo Medicina general.",
            voiceScript:
                "Ahora elige la especialidad. Si no estás segura, Medicina general suele ser un buen primer paso.",
            focusSection: .serviceAndSpecialty,
            scrollAnchor: .specialtyField
        ),
        GuidedSessionStep(
            id: 3,
            screenSummary: "Aquí eliges el día; los huecos suelen verse como pastillas pequeñas.",
            recommendedNextStep: "Toca un día que te venga bien en la fila de fechas.",
            voiceScript:
                "Mira la fila de días y elige uno que te encaje. No pasa nada si cambias después si el portal lo permite.",
            focusSection: .dateAndSlot,
            scrollAnchor: .dateRow
        ),
        GuidedSessionStep(
            id: 4,
            screenSummary: "Después del día, eliges la franja horaria.",
            recommendedNextStep: "Elige una hora disponible; a veces aparece resaltada.",
            voiceScript:
                "Ahora las horas. Toca una franja que te vaya bien. Si no te gusta ninguna, podemos volver al día anterior.",
            focusSection: .dateAndSlot,
            scrollAnchor: .timeSlots
        ),
        GuidedSessionStep(
            id: 5,
            screenSummary: "Te piden nombre y apellidos en un campo estrecho.",
            recommendedNextStep: "Escribe tu nombre como suele aparecer en tu documento.",
            voiceScript:
                "Escribe tu nombre y apellidos en el campo de texto. Despacio, sin prisa.",
            focusSection: .patientDetails,
            scrollAnchor: .nameField
        ),
        GuidedSessionStep(
            id: 6,
            screenSummary: "Necesitan un teléfono o forma de contacto para confirmarte.",
            recommendedNextStep: "Escribe un teléfono donde te puedan localizar.",
            voiceScript:
                "Añade un teléfono de contacto. Con eso suele bastar para que te llamen o escriban.",
            focusSection: .patientDetails,
            scrollAnchor: .phoneField
        ),
        GuidedSessionStep(
            id: 7,
            screenSummary: "Hay casillas de recordatorios y correos; no todas son obligatorias.",
            recommendedNextStep: "Si quieres SMS de recordatorio, déjalo activado; lo demás puedes ignorarlo.",
            voiceScript:
                "Revisa la casilla del SMS recordatorio si te ayuda. El resto de marketing puedes dejarlo apagado si no lo deseas.",
            focusSection: .patientDetails,
            scrollAnchor: .smsToggle
        ),
        GuidedSessionStep(
            id: 8,
            screenSummary: "Al final aparece un resumen con especialidad, día y centro.",
            recommendedNextStep: "Lee despacio que coincida con lo que querías.",
            voiceScript:
                "Antes de confirmar, mira el resumen: especialidad, día, hora y centro. Si algo no cuadra, vuelve atrás con calma.",
            focusSection: .confirmation,
            scrollAnchor: .confirmationSummary
        ),
        GuidedSessionStep(
            id: 9,
            screenSummary: "El botón verde suele ser el definitivo; al lado hay borrador o cancelar.",
            recommendedNextStep: "Cuando estés lista, pulsa el botón principal para confirmar la cita.",
            voiceScript:
                "Cuando todo te encaje, pulsa el botón principal de confirmar cita. Yo me quedo aquí por si lo necesitas.",
            focusSection: .confirmation,
            scrollAnchor: .confirmButton
        ),
        GuidedSessionStep(
            id: 10,
            screenSummary: "La página confirma que la solicitud se ha enviado.",
            recommendedNextStep: "Puedes salir del acompañamiento cuando quieras.",
            voiceScript:
                "Listo: la cita quedó registrada en el portal. Buen trabajo. Si quieres, puedes cerrar el asistente o volver al inicio.",
            focusSection: .confirmation,
            scrollAnchor: .successBanner
        )
    ]
}
