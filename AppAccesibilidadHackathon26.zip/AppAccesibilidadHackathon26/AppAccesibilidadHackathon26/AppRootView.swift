//
//  AppRootView.swift
//  AppAccesibilidadHackathon26
//

import SwiftUI

enum MainEntryMode: Equatable {
    case personalization
    case explore
}

private enum AppFlowPhase: Equatable {
    case splash
    case welcome
    case onboarding
    case home(MainEntryMode)
}

struct AppRootView: View {
    @AppStorage("hasCompletedFirstFlow") private var hasCompletedFirstFlow = false
    @AppStorage("homeEntryPersonalization") private var homeEntryPersonalization = false

    @State private var phase: AppFlowPhase = .splash
    @State private var onboardingSessionID = UUID()

    var body: some View {
        Group {
            switch phase {
            case .splash:
                SplashEntryView {
                    advanceFromSplash()
                }
            case .welcome:
                WelcomeView(
                    onPersonalizeNow: {
                        goToOnboarding()
                    },
                    onExploreFirst: {
                        persistHomeEntry(personalization: false)
                        phase = .home(.explore)
                    }
                )
            case .onboarding:
                OnboardingFlowView {
                    persistHomeEntry(personalization: true)
                    phase = .home(.personalization)
                }
                .id(onboardingSessionID)
            case .home(let mode):
                ContentView(entryMode: mode, onOpenPersonalization: goToOnboarding)
            }
        }
        .animation(.easeInOut(duration: 0.28), value: phase)
    }

    private func advanceFromSplash() {
        if hasCompletedFirstFlow {
            phase = .home(homeEntryPersonalization ? .personalization : .explore)
        } else {
            phase = .welcome
        }
    }

    private func goToOnboarding() {
        onboardingSessionID = UUID()
        phase = .onboarding
    }

    private func persistHomeEntry(personalization: Bool) {
        hasCompletedFirstFlow = true
        homeEntryPersonalization = personalization
    }
}

#Preview("App — flujo completo") {
    AppRootView()
}
