//
//  AppointmentBookingMockViews.swift
//  AppAccesibilidadHackathon26
//
//  Simulated “foreign” clinic portal: dense vs simplified; focus dims non-target blocks.
//

import SwiftUI

// MARK: - Guided session autoscroll (mock form)

private enum AppointmentMockScrollPolicy {
    /// Keeps the active anchor in the upper–middle of the viewport so the live-session assistant bubble does not cover it.
    static let viewportAnchor = UnitPoint(x: 0.5, y: 0.34)
    static let bottomContentPadding: CGFloat = 240

    static func scrollToAnchor(_ anchor: AppointmentMockScrollAnchor, proxy: ScrollViewProxy, animated: Bool) {
        if animated {
            withAnimation(.easeInOut(duration: 0.35)) {
                proxy.scrollTo(anchor.rawValue, anchor: viewportAnchor)
            }
        } else {
            proxy.scrollTo(anchor.rawValue, anchor: viewportAnchor)
        }
    }

    /// Second layout pass when the target view may not exist yet (e.g. success banner on the last step).
    static func scrollToAnchorDeferred(_ anchor: AppointmentMockScrollAnchor, proxy: ScrollViewProxy, animated: Bool) {
        DispatchQueue.main.async {
            scrollToAnchor(anchor, proxy: proxy, animated: animated)
        }
    }
}

// MARK: - Form state (driven by guided step index in session)

struct AppointmentMockFormState: Equatable {
    var centerLabel: String
    var specialtyLabel: String
    var selectedDay: String?
    var selectedSlot: String?
    var patientName: String
    var patientPhone: String
    var smsReminder: Bool
    var newsletter: Bool
    var appointmentConfirmed: Bool

    static func configuration(forStepIndex step: Int) -> AppointmentMockFormState {
        var s = AppointmentMockFormState(
            centerLabel: "Seleccione centro…",
            specialtyLabel: "Seleccione especialidad…",
            selectedDay: nil,
            selectedSlot: nil,
            patientName: "",
            patientPhone: "",
            smsReminder: true,
            newsletter: false,
            appointmentConfirmed: false
        )
        if step >= 1 { s.centerLabel = "Centro Sur — planta 2" }
        if step >= 2 { s.specialtyLabel = "Medicina general" }
        if step >= 3 { s.selectedDay = "Mié 5" }
        if step >= 4 { s.selectedSlot = "10:30" }
        if step >= 5 { s.patientName = "María Elena García" }
        if step >= 6 { s.patientPhone = "+34 600 000 000" }
        if step >= 10 { s.appointmentConfirmed = true }
        return s
    }

    var summaryLine: String {
        let spec = specialtyLabel.contains("Seleccione") ? "—" : specialtyLabel
        let day = selectedDay ?? "—"
        let slot = selectedSlot ?? "—"
        let center = centerLabel.contains("Seleccione") ? "—" : "Centro Sur"
        return "\(spec) · \(day) · \(slot) · \(center)"
    }
}

// MARK: - Container

struct AppointmentBookingMockContainer: View {
    let stepIndex: Int
    let isSimplified: Bool
    let focusModeActive: Bool
    let scrollAnchor: AppointmentMockScrollAnchor

    private var focusSection: AppointmentMockFocusSection {
        let steps = GuidedSessionStep.appointmentDemo
        let idx = min(max(stepIndex, 0), steps.count - 1)
        return steps[idx].focusSection
    }

    private var formState: AppointmentMockFormState {
        AppointmentMockFormState.configuration(forStepIndex: stepIndex)
    }

    var body: some View {
        Group {
            if isSimplified {
                AppointmentBookingSimplifiedMockView(
                    stepIndex: stepIndex,
                    focusSection: focusSection,
                    focusModeActive: focusModeActive,
                    formState: formState,
                    scrollAnchor: scrollAnchor
                )
            } else {
                AppointmentBookingDenseMockView(
                    formState: formState,
                    focusSection: focusSection,
                    focusModeActive: focusModeActive,
                    scrollAnchor: scrollAnchor
                )
            }
        }
        /// Simulated third-party portal: not a11y-perfect; real guidance is the assistant bubble.
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Formulario de ejemplo del portal clínico, solo para la demo.")
    }
}

// MARK: - Dense mock

struct AppointmentBookingDenseMockView: View {
    let formState: AppointmentMockFormState
    let focusSection: AppointmentMockFocusSection
    let focusModeActive: Bool
    let scrollAnchor: AppointmentMockScrollAnchor

    private let days = ["Lun 3", "Mar 4", "Mié 5", "Jue 6", "Vie 7"]
    private let slots = ["09:10", "10:30", "11:00", "16:15"]

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    clutterStack

                    denseSpecialtyBlock
                    denseDateBlock
                    densePatientBlock
                    denseConfirmationBlock

                    if formState.appointmentConfirmed {
                        successBanner(boost: focusBoost(for: .confirmation))
                            .id(AppointmentMockScrollAnchor.successBanner.rawValue)
                    }
                }
                .padding(.bottom, AppointmentMockScrollPolicy.bottomContentPadding)
            }
            .background(Color(red: 0.94, green: 0.93, blue: 0.91))
            .onAppear {
                applyScrollForAnchor(scrollAnchor, proxy: proxy, deferSuccessBannerRetry: true)
            }
            .onChange(of: scrollAnchor) { _, new in
                applyScrollForAnchor(new, proxy: proxy, deferSuccessBannerRetry: true)
            }
            .onChange(of: formState.appointmentConfirmed) { _, confirmed in
                guard confirmed, scrollAnchor == .successBanner else { return }
                AppointmentMockScrollPolicy.scrollToAnchorDeferred(.successBanner, proxy: proxy, animated: true)
            }
        }
    }

    private func applyScrollForAnchor(_ anchor: AppointmentMockScrollAnchor, proxy: ScrollViewProxy, deferSuccessBannerRetry: Bool) {
        AppointmentMockScrollPolicy.scrollToAnchor(anchor, proxy: proxy, animated: true)
        if deferSuccessBannerRetry, anchor == .successBanner {
            AppointmentMockScrollPolicy.scrollToAnchorDeferred(anchor, proxy: proxy, animated: true)
        }
    }

    /// When focus mode is on, the active step’s block uses larger type and roomier layout (tool “boost”).
    private func focusBoost(for section: AppointmentMockFocusSection) -> Bool {
        focusModeActive && focusSection == section
    }

    private var clutterStack: some View {
        let boost = focusBoost(for: .topClutter)
        return dimmed(.topClutter) {
            VStack(alignment: .leading, spacing: boost ? 14 : 8) {
                denseHeader(boost: boost)
                denseLegalStrip(boost: boost)
                densePromoScroll(boost: boost)
                denseOffersRow(boost: boost)
            }
            .id(AppointmentMockScrollAnchor.topClutter.rawValue)
        }
    }

    private func dimmed<Content: View>(_ section: AppointmentMockFocusSection, @ViewBuilder content: () -> Content) -> some View {
        let isTarget = section == focusSection
        let opacity = focusModeActive ? (isTarget ? 1.0 : 0.34) : 1.0
        let boost = focusBoost(for: section)
        return content()
            .padding(boost ? 2 : 0)
            .background(
                Group {
                    if boost {
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .fill(AppPalette.primaryMuted.opacity(0.55))
                    }
                }
            )
            .opacity(opacity)
            .overlay {
                if focusModeActive && isTarget {
                    RoundedRectangle(cornerRadius: boost ? 14 : 10, style: .continuous)
                        .strokeBorder(AppPalette.primary, lineWidth: boost ? 3 : 2)
                        .padding(boost ? -6 : -4)
                }
            }
    }

    private func denseHeader(boost: Bool) -> some View {
        HStack(alignment: .top, spacing: boost ? 12 : 8) {
            RoundedRectangle(cornerRadius: 4)
                .fill(Color(red: 0.2, green: 0.45, blue: 0.62))
                .frame(width: boost ? 44 : 36, height: boost ? 44 : 36)
            VStack(alignment: .leading, spacing: boost ? 6 : 2) {
                Text("SaludPlus | Portal pacientes")
                    .font(boost ? .body.weight(.semibold) : .caption.weight(.semibold))
                    .foregroundStyle(Color(red: 0.15, green: 0.15, blue: 0.18))
                Text("Clínica ejemplo · Zona centro · #1 en confusión UX")
                    .font(boost ? .subheadline : .system(size: 9))
                    .foregroundStyle(Color(red: 0.45, green: 0.45, blue: 0.5))
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
            VStack(alignment: .trailing, spacing: boost ? 8 : 4) {
                HStack(spacing: boost ? 10 : 6) {
                    Text("Ayuda")
                        .font(boost ? .subheadline : .system(size: 9))
                    Text("Mi cuenta")
                        .font(boost ? .subheadline : .system(size: 9))
                    Image(systemName: "bell.fill")
                        .font(boost ? .body : .system(size: 11))
                }
                if boost {
                    Text("(Puede ignorar esto por ahora)")
                        .font(.caption)
                        .foregroundStyle(AppPalette.primary)
                }
            }
            .foregroundStyle(Color(red: 0.4, green: 0.4, blue: 0.45))
        }
        .padding(boost ? 16 : 10)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: boost ? 12 : 8))
    }

    private func denseLegalStrip(boost: Bool) -> some View {
        Text(
            "Al continuar acepta términos, política de privacidad LOPD-GDD y cookies según RD 2024/00. Revise consentimientos y preferencias de comunicación comercial. BANNER: Oferta flash solo hoy."
        )
        .font(boost ? .footnote : .system(size: 8))
        .lineSpacing(boost ? 4 : 0)
        .foregroundStyle(Color(red: 0.42, green: 0.42, blue: 0.48))
        .fixedSize(horizontal: false, vertical: true)
        .padding(.horizontal, boost ? 4 : 6)
    }

    private func densePromoScroll(boost: Bool) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: boost ? 12 : 8) {
                promoCard(title: "Vacuna gripe", subtitle: "Cupos limitados", boost: boost)
                promoCard(title: "Revisión anual", subtitle: "-15% socios", boost: boost)
                promoCard(title: "Telemedicina", subtitle: "Nuevo", boost: boost)
                promoCard(title: "Prueba genética", subtitle: "¡Últimas plazas!", boost: boost)
            }
        }
    }

    private func promoCard(title: String, subtitle: String, boost: Bool) -> some View {
        VStack(alignment: .leading, spacing: boost ? 6 : 4) {
            Text(title)
                .font(boost ? .subheadline.weight(.semibold) : .system(size: 10).weight(.semibold))
            Text(subtitle)
                .font(boost ? .caption : .system(size: 8))
                .foregroundStyle(Color(red: 0.45, green: 0.45, blue: 0.5))
        }
        .padding(boost ? 14 : 10)
        .frame(width: boost ? 148 : 120, alignment: .leading)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .strokeBorder(Color(red: 0.88, green: 0.86, blue: 0.82), lineWidth: 1)
        )
    }

    private func denseOffersRow(boost: Bool) -> some View {
        VStack(alignment: .leading, spacing: boost ? 8 : 0) {
            Text("También le puede interesar: nutrición · fisioterapia · analíticas · psicología · dentista · podología")
                .font(boost ? .footnote : .system(size: 8))
                .foregroundStyle(Color(red: 0.38, green: 0.38, blue: 0.44))
                .fixedSize(horizontal: false, vertical: true)
            if boost {
                Button("Ver más") {}
                    .font(.subheadline.weight(.medium))
                    .buttonStyle(.plain)
                    .foregroundStyle(AppPalette.primary)
            } else {
                HStack {
                    Spacer()
                    Button("Ver más") {}
                        .font(.system(size: 8))
                        .buttonStyle(.plain)
                        .foregroundStyle(Color.blue.opacity(0.85))
                }
            }
        }
    }

    private var denseSpecialtyBlock: some View {
        let boost = focusBoost(for: .serviceAndSpecialty)
        return dimmed(.serviceAndSpecialty) {
            VStack(alignment: .leading, spacing: boost ? 16 : 8) {
                Text("Pedir cita · Paso 1 de 4")
                    .font(boost ? .headline.weight(.bold) : .system(size: 10).weight(.bold))
                    .foregroundStyle(Color(red: 0.12, green: 0.12, blue: 0.15))
                Text("Especialidad o servicio")
                    .font(boost ? .title3.weight(.semibold) : .system(size: 9).weight(.semibold))
                mockFieldLabel("Centro (obligatorio)", boost: boost)
                HStack {
                    Text(formState.centerLabel)
                        .font(boost ? .body : .system(size: 9))
                        .foregroundStyle(
                            formState.centerLabel.contains("Seleccione")
                                ? Color(red: 0.55, green: 0.52, blue: 0.5)
                                : Color(red: 0.35, green: 0.35, blue: 0.4)
                        )
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.down")
                        .font(boost ? .body.weight(.semibold) : .system(size: 9))
                }
                .padding(boost ? 14 : 8)
                .frame(minHeight: boost ? 48 : nil)
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: boost ? 10 : 6))
                .overlay(
                    RoundedRectangle(cornerRadius: boost ? 10 : 6)
                        .strokeBorder(boost ? AppPalette.border : Color.clear, lineWidth: 1)
                )
                .id(AppointmentMockScrollAnchor.centerField.rawValue)

                mockFieldLabel("Especialidad", boost: boost)
                HStack {
                    Text(formState.specialtyLabel)
                        .font(boost ? .body.weight(.medium) : .system(size: 9))
                        .foregroundStyle(
                            formState.specialtyLabel.contains("Seleccione")
                                ? Color(red: 0.55, green: 0.52, blue: 0.5)
                                : Color(red: 0.2, green: 0.2, blue: 0.22)
                        )
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.down")
                        .font(boost ? .body.weight(.semibold) : .system(size: 9))
                }
                .padding(boost ? 14 : 8)
                .frame(minHeight: boost ? 48 : nil)
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: boost ? 10 : 6))
                .overlay(
                    RoundedRectangle(cornerRadius: boost ? 10 : 6)
                        .strokeBorder(boost ? AppPalette.border : Color.clear, lineWidth: 1)
                )
                .id(AppointmentMockScrollAnchor.specialtyField.rawValue)

                if boost {
                    VStack(alignment: .leading, spacing: 10) {
                        Button("Borrar filtros") {}
                            .font(.subheadline.weight(.medium))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .buttonStyle(.bordered)
                        Button("Ver calendario completo") {}
                            .font(.subheadline.weight(.medium))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .buttonStyle(.bordered)
                    }
                } else {
                    HStack(spacing: 8) {
                        Button("Borrar filtros") {}
                            .font(.system(size: 8))
                            .buttonStyle(.bordered)
                        Button("Ver calendario completo") {}
                            .font(.system(size: 8))
                            .buttonStyle(.bordered)
                    }
                }
            }
            .padding(boost ? 18 : 10)
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: boost ? 14 : 10))
            .shadow(color: .black.opacity(0.06), radius: 4, y: 2)
        }
    }

    private var denseDateBlock: some View {
        let boost = focusBoost(for: .dateAndSlot)
        return dimmed(.dateAndSlot) {
            VStack(alignment: .leading, spacing: boost ? 16 : 8) {
                Text("Fecha y hora preferida")
                    .font(boost ? .title3.weight(.semibold) : .system(size: 9).weight(.semibold))
                if boost {
                    Text("Días disponibles")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(AppPalette.textSecondary)
                }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: boost ? 10 : 6) {
                        ForEach(days, id: \.self) { day in
                            Text(day)
                                .font(boost ? .body.weight(formState.selectedDay == day ? .semibold : .regular) : .system(size: 8))
                                .padding(.vertical, boost ? 12 : 6)
                                .padding(.horizontal, boost ? 14 : 8)
                                .background(dayBackground(for: day))
                                .clipShape(RoundedRectangle(cornerRadius: boost ? 8 : 4))
                        }
                    }
                }
                .id(AppointmentMockScrollAnchor.dateRow.rawValue)
                Text(boost ? "Horarios" : "Franjas")
                    .font(boost ? .subheadline.weight(.semibold) : .system(size: 8))
                    .foregroundStyle(boost ? AppPalette.textSecondary : Color.primary)
                Group {
                    if boost {
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 88), spacing: 10)], spacing: 10) {
                            ForEach(slots, id: \.self) { slot in
                                slotPill(slot, selected: formState.selectedSlot == slot, boost: true)
                            }
                        }
                    } else {
                        HStack(spacing: 6) {
                            ForEach(slots, id: \.self) { slot in
                                slotPill(slot, selected: formState.selectedSlot == slot, boost: false)
                            }
                        }
                    }
                }
                .id(AppointmentMockScrollAnchor.timeSlots.rawValue)
                Text("Zona horaria Europe/Madrid · sujeto a disponibilidad real · recarga la página si falla")
                    .font(boost ? .caption : .system(size: 7))
                    .foregroundStyle(Color(red: 0.45, green: 0.45, blue: 0.5))
            }
            .padding(boost ? 18 : 10)
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: boost ? 14 : 10))
            .shadow(color: .black.opacity(0.05), radius: 3, y: 1)
        }
    }

    private func dayBackground(for day: String) -> Color {
        if let sel = formState.selectedDay, sel == day {
            return Color.green.opacity(0.28)
        }
        return Color(red: 0.93, green: 0.92, blue: 0.9)
    }

    private func slotPill(_ t: String, selected: Bool, boost: Bool) -> some View {
        Group {
            if boost {
                Text(t)
                    .font(.body.weight(selected ? .semibold : .regular))
                    .padding(.vertical, 10)
                    .padding(.horizontal, 16)
                    .frame(maxWidth: .infinity)
                    .background(selected ? AppPalette.primary.opacity(0.28) : Color(red: 0.93, green: 0.92, blue: 0.9))
                    .clipShape(Capsule())
                    .overlay(
                        Capsule()
                            .strokeBorder(selected ? AppPalette.primary.opacity(0.5) : Color.clear, lineWidth: 1.5)
                    )
            } else {
                Text(t)
                    .font(.system(size: 8).weight(selected ? .semibold : .regular))
                    .padding(.vertical, 5)
                    .padding(.horizontal, 10)
                    .background(selected ? AppPalette.primary.opacity(0.22) : Color(red: 0.93, green: 0.92, blue: 0.9))
                    .clipShape(Capsule())
            }
        }
    }

    private var densePatientBlock: some View {
        let boost = focusBoost(for: .patientDetails)
        return dimmed(.patientDetails) {
            VStack(alignment: .leading, spacing: boost ? 16 : 8) {
                Text("Datos de contacto")
                    .font(boost ? .title3.weight(.semibold) : .system(size: 9).weight(.semibold))
                mockFieldLabel("Nombre y apellidos", boost: boost)
                Rectangle()
                    .fill(Color(red: 0.96, green: 0.96, blue: 0.97))
                    .frame(height: boost ? 52 : 26)
                    .overlay(alignment: .leading) {
                        Text(formState.patientName.isEmpty ? " " : formState.patientName)
                            .font(boost ? .body : .system(size: 9))
                            .padding(.horizontal, boost ? 14 : 8)
                            .foregroundStyle(
                                formState.patientName.isEmpty
                                    ? Color(red: 0.75, green: 0.73, blue: 0.7)
                                    : Color(red: 0.25, green: 0.25, blue: 0.3)
                            )
                    }
                    .clipShape(RoundedRectangle(cornerRadius: boost ? 8 : 4))
                    .overlay(alignment: .leading) {
                        if formState.patientName.isEmpty {
                            Text("Escriba aquí…")
                                .font(boost ? .body : .system(size: 9))
                                .padding(.horizontal, boost ? 14 : 8)
                                .foregroundStyle(Color(red: 0.55, green: 0.53, blue: 0.5))
                        }
                    }
                    .overlay(
                        RoundedRectangle(cornerRadius: boost ? 8 : 4)
                            .strokeBorder(boost ? AppPalette.border : Color.clear, lineWidth: 1)
                    )
                    .id(AppointmentMockScrollAnchor.nameField.rawValue)
                mockFieldLabel("Teléfono", boost: boost)
                Rectangle()
                    .fill(Color(red: 0.96, green: 0.96, blue: 0.97))
                    .frame(height: boost ? 52 : 26)
                    .overlay(alignment: .leading) {
                        Text(formState.patientPhone.isEmpty ? " " : formState.patientPhone)
                            .font(boost ? .body : .system(size: 9))
                            .padding(.horizontal, boost ? 14 : 8)
                            .foregroundStyle(
                                formState.patientPhone.isEmpty
                                    ? Color(red: 0.75, green: 0.73, blue: 0.7)
                                    : Color(red: 0.25, green: 0.25, blue: 0.3)
                            )
                    }
                    .clipShape(RoundedRectangle(cornerRadius: boost ? 8 : 4))
                    .overlay(alignment: .leading) {
                        if formState.patientPhone.isEmpty {
                            Text("+34 …")
                                .font(boost ? .body : .system(size: 9))
                                .padding(.horizontal, boost ? 14 : 8)
                                .foregroundStyle(Color(red: 0.55, green: 0.53, blue: 0.5))
                        }
                    }
                    .overlay(
                        RoundedRectangle(cornerRadius: boost ? 8 : 4)
                            .strokeBorder(boost ? AppPalette.border : Color.clear, lineWidth: 1)
                    )
                    .id(AppointmentMockScrollAnchor.phoneField.rawValue)
                Toggle(isOn: .constant(formState.smsReminder)) {
                    Text("Acepto recibir SMS recordatorio")
                        .font(boost ? .body : .system(size: 8))
                        .fixedSize(horizontal: false, vertical: true)
                }
                .tint(Color(red: 0.2, green: 0.45, blue: 0.62))
                .disabled(true)
                .id(AppointmentMockScrollAnchor.smsToggle.rawValue)
                Toggle(isOn: .constant(formState.newsletter)) {
                    Text("Newsletter bienestar · promos · encuestas")
                        .font(boost ? .subheadline : .system(size: 8))
                        .fixedSize(horizontal: false, vertical: true)
                }
                .tint(Color(red: 0.2, green: 0.45, blue: 0.62))
                .disabled(true)
            }
            .padding(boost ? 18 : 10)
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: boost ? 14 : 10))
        }
    }

    private var denseConfirmationBlock: some View {
        let boost = focusBoost(for: .confirmation)
        return dimmed(.confirmation) {
            VStack(alignment: .leading, spacing: boost ? 16 : 8) {
                Text("Resumen")
                    .font(boost ? .title3.weight(.semibold) : .system(size: 9).weight(.semibold))
                    .id(AppointmentMockScrollAnchor.confirmationSummary.rawValue)
                Text(formState.summaryLine)
                    .font(boost ? .body.weight(.medium) : .system(size: 8))
                    .foregroundStyle(Color(red: 0.35, green: 0.35, blue: 0.4))
                    .lineSpacing(boost ? 4 : 0)
                    .padding(boost ? 12 : 0)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(boost ? AppPalette.surfaceMuted : Color.clear)
                    .clipShape(RoundedRectangle(cornerRadius: boost ? 10 : 0))
                if boost {
                    VStack(spacing: 12) {
                        Button("Confirmar cita") {}
                            .font(.headline.weight(.semibold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(Color(red: 0.18, green: 0.48, blue: 0.38))
                            .foregroundStyle(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                            .id(AppointmentMockScrollAnchor.confirmButton.rawValue)
                        Button("Guardar borrador") {}
                            .font(.subheadline.weight(.medium))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .buttonStyle(.bordered)
                        Button("Cancelar") {}
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(Color.red.opacity(0.85))
                    }
                } else {
                    HStack(spacing: 8) {
                        Button("Confirmar cita") {}
                            .font(.system(size: 9).weight(.semibold))
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(Color(red: 0.18, green: 0.48, blue: 0.38))
                            .foregroundStyle(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 6))
                            .id(AppointmentMockScrollAnchor.confirmButton.rawValue)
                        Button("Guardar borrador") {}
                            .font(.system(size: 8))
                            .buttonStyle(.bordered)
                        Button("Cancelar") {}
                            .font(.system(size: 8))
                            .foregroundStyle(Color.red.opacity(0.8))
                    }
                }
                Text("¿Problemas? Llame al 900 000 000 (l-v 8-20h) · chatbot · FAQ 47 páginas")
                    .font(boost ? .footnote : .system(size: 7))
                    .foregroundStyle(Color.blue.opacity(0.75))
                    .lineSpacing(boost ? 3 : 0)
            }
            .padding(boost ? 18 : 10)
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: boost ? 14 : 10))
        }
    }

    private func successBanner(boost: Bool) -> some View {
        VStack(alignment: .leading, spacing: boost ? 10 : 6) {
            HStack(spacing: boost ? 12 : 8) {
                Image(systemName: "checkmark.circle.fill")
                    .font(boost ? .title2 : .body)
                    .foregroundStyle(AppPalette.success)
                Text("Cita solicitada")
                    .font(boost ? .title2.weight(.bold) : .system(size: 11).weight(.bold))
                    .foregroundStyle(Color(red: 0.12, green: 0.12, blue: 0.15))
            }
            Text("Recibirá confirmación por SMS o correo según los datos indicados.")
                .font(boost ? .body : .system(size: 9))
                .foregroundStyle(Color(red: 0.38, green: 0.38, blue: 0.44))
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(boost ? 18 : 12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(red: 0.9, green: 0.97, blue: 0.92))
        .clipShape(RoundedRectangle(cornerRadius: boost ? 14 : 10))
        .overlay(
            RoundedRectangle(cornerRadius: boost ? 14 : 10)
                .strokeBorder(AppPalette.success.opacity(0.45), lineWidth: boost ? 2 : 1)
        )
    }

    private func mockFieldLabel(_ text: String, boost: Bool) -> some View {
        Text(text)
            .font(boost ? .subheadline.weight(.medium) : .system(size: 8))
            .foregroundStyle(boost ? AppPalette.textSecondary : Color(red: 0.4, green: 0.4, blue: 0.45))
    }
}

// MARK: - Simplified mock

struct AppointmentBookingSimplifiedMockView: View {
    let stepIndex: Int
    let focusSection: AppointmentMockFocusSection
    let focusModeActive: Bool
    var formState: AppointmentMockFormState = .configuration(forStepIndex: 0)
    let scrollAnchor: AppointmentMockScrollAnchor

    private var stepDisplay: Int {
        min(stepIndex + 1, GuidedSessionStep.appointmentDemo.count)
    }

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("Paso \(stepDisplay) de \(GuidedSessionStep.appointmentDemo.count)")
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(AppPalette.primary)

                    simplifiedStepBody
                }
                .padding(16)
                .padding(.bottom, AppointmentMockScrollPolicy.bottomContentPadding)
            }
            .background(AppPalette.surfaceMuted)
            .onAppear {
                applyScrollForAnchor(scrollAnchor, proxy: proxy, deferSuccessBannerRetry: true)
            }
            .onChange(of: scrollAnchor) { _, new in
                applyScrollForAnchor(new, proxy: proxy, deferSuccessBannerRetry: true)
            }
            .onChange(of: formState.appointmentConfirmed) { _, confirmed in
                guard confirmed, scrollAnchor == .successBanner else { return }
                AppointmentMockScrollPolicy.scrollToAnchorDeferred(.successBanner, proxy: proxy, animated: true)
            }
        }
    }

    private func applyScrollForAnchor(_ anchor: AppointmentMockScrollAnchor, proxy: ScrollViewProxy, deferSuccessBannerRetry: Bool) {
        AppointmentMockScrollPolicy.scrollToAnchor(anchor, proxy: proxy, animated: true)
        if deferSuccessBannerRetry, anchor == .successBanner {
            AppointmentMockScrollPolicy.scrollToAnchorDeferred(anchor, proxy: proxy, animated: true)
        }
    }

    @ViewBuilder
    private var simplifiedStepBody: some View {
        let idx = min(max(stepIndex, 0), GuidedSessionStep.appointmentDemo.count - 1)
        switch idx {
        case 0:
            simplifiedBlock(.topClutter) {
                Text("Mucha información arriba")
                    .font(.headline)
                Text("Baja al formulario con calma.")
                    .font(.body)
                    .foregroundStyle(AppPalette.textSecondary)
            }
            .id(AppointmentMockScrollAnchor.topClutter.rawValue)
        case 1, 2:
            VStack(alignment: .leading, spacing: 16) {
                simplifiedBlock(.serviceAndSpecialty) {
                    Text("Centro")
                        .font(.headline)
                    Text(formState.centerLabel)
                        .font(.body.weight(.medium))
                }
                .id(AppointmentMockScrollAnchor.centerField.rawValue)

                simplifiedBlock(.serviceAndSpecialty) {
                    Text("Especialidad")
                        .font(.headline)
                    Text(formState.specialtyLabel)
                        .font(.body.weight(.medium))
                }
                .id(AppointmentMockScrollAnchor.specialtyField.rawValue)
            }
        case 3, 4:
            VStack(alignment: .leading, spacing: 16) {
                simplifiedBlock(.dateAndSlot) {
                    Text("Día")
                        .font(.headline)
                    Text(formState.selectedDay ?? "—")
                        .font(.title3.weight(.semibold))
                }
                .id(AppointmentMockScrollAnchor.dateRow.rawValue)

                simplifiedBlock(.dateAndSlot) {
                    Text("Hora")
                        .font(.headline)
                    Text(formState.selectedSlot ?? "—")
                        .font(.title3.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(AppPalette.primaryMuted)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .id(AppointmentMockScrollAnchor.timeSlots.rawValue)
            }
        case 5, 6, 7:
            VStack(alignment: .leading, spacing: 16) {
                simplifiedBlock(.patientDetails) {
                    Text("Nombre y apellidos")
                        .font(.headline)
                    Text(formState.patientName.isEmpty ? "—" : formState.patientName)
                        .font(.body)
                }
                .id(AppointmentMockScrollAnchor.nameField.rawValue)

                simplifiedBlock(.patientDetails) {
                    Text("Teléfono")
                        .font(.headline)
                    Text(formState.patientPhone.isEmpty ? "—" : formState.patientPhone)
                        .font(.body)
                }
                .id(AppointmentMockScrollAnchor.phoneField.rawValue)

                simplifiedBlock(.patientDetails) {
                    Text("Recordatorios")
                        .font(.headline)
                    Text(formState.smsReminder ? "SMS de recordatorio: activado" : "SMS de recordatorio: desactivado")
                        .font(.body)
                        .foregroundStyle(AppPalette.textSecondary)
                }
                .id(AppointmentMockScrollAnchor.smsToggle.rawValue)
            }
        default:
            VStack(alignment: .leading, spacing: 16) {
                simplifiedBlock(.confirmation) {
                    Text("Resumen")
                        .font(.headline)
                    Text(formState.summaryLine)
                        .font(.body.weight(.medium))
                }
                .id(AppointmentMockScrollAnchor.confirmationSummary.rawValue)

                simplifiedBlock(.confirmation) {
                    Text("Confirmar")
                        .font(.headline)
                    Button("Confirmar cita") {}
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(AppPalette.primary)
                        .foregroundStyle(AppPalette.primaryOnPrimary)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .allowsHitTesting(false)
                }
                .id(AppointmentMockScrollAnchor.confirmButton.rawValue)

                if formState.appointmentConfirmed {
                    simplifiedBlock(.confirmation) {
                        Text("Cita confirmada")
                            .font(.title3.weight(.semibold))
                            .foregroundStyle(AppPalette.success)
                        Text("Recibirás confirmación por SMS o correo según los datos indicados.")
                            .font(.body)
                            .foregroundStyle(AppPalette.textSecondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .id(AppointmentMockScrollAnchor.successBanner.rawValue)
                }
            }
        }
    }

    private func simplifiedBlock<Content: View>(
        _ section: AppointmentMockFocusSection,
        @ViewBuilder content: () -> Content
    ) -> some View {
        let isTarget = section == focusSection
        let opacity = focusModeActive ? (isTarget ? 1.0 : 0.35) : 1.0
        return VStack(alignment: .leading, spacing: 12, content: content)
            .frame(maxWidth: .infinity, alignment: .leading)
            .opacity(opacity)
            .padding(16)
            .background(AppPalette.surface)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .overlay {
                if focusModeActive && isTarget {
                    RoundedRectangle(cornerRadius: 14)
                        .strokeBorder(AppPalette.primary, lineWidth: 2)
                }
            }
    }
}
