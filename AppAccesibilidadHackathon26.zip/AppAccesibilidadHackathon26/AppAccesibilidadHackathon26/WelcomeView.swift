//
//  WelcomeView.swift
//  AppAccesibilidadHackathon26
//

import SwiftUI

struct WelcomeView: View {
    let onPersonalizeNow: () -> Void
    let onExploreFirst: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Vamos a adaptar la experiencia a ti")
                    .font(.largeTitle.bold())
                    .foregroundStyle(AppPalette.textPrimary)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityAddTraits(.isHeader)

                Text(
                    "Puedes personalizar la app en menos de un minuto. También puedes explorar primero y cambiarlo después."
                )
                .font(.body)
                    .foregroundStyle(AppPalette.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .lineSpacing(4)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 24)
            .padding(.top, 32)
            .padding(.bottom, 24)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            VStack(spacing: 12) {
                Button {
                    onPersonalizeNow()
                } label: {
                    Text("Personalizar ahora")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                }
                .buttonStyle(.borderedProminent)
                .tint(AppPalette.primary)
                .foregroundStyle(AppPalette.primaryOnPrimary)
                .accessibilityHint("Abre el inicio preparado para personalizar la app")

                Button {
                    onExploreFirst()
                } label: {
                    Text("Explorar primero")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                }
                .buttonStyle(.bordered)
                .tint(AppPalette.primary)
                .accessibilityHint("Entra al inicio sin personalizar; podrás cambiarlo después")
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 16)
            .background(AppPalette.canvas)
        }
        .background(AppPalette.canvas)
    }
}

#Preview {
    WelcomeView(onPersonalizeNow: {}, onExploreFirst: {})
}
