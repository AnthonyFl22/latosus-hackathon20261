//
//  MessyPortalFormScreenshotView.swift
//  AppAccesibilidadHackathon26
//
//  Pantalla aislada solo para Previews / capturas: el mismo mock denso del portal
//  (“messy form”) que en la sesión guiada, sin burbuja ni foco. No está enlazada
//  a AppRootView ni a ningún flujo.
//

import SwiftUI

/// Cromado neutro (estilo Safari/Chrome móvil, sin marca): barra de URL + controles típicos.
/// Compartido entre capturas (`MessyPortalFormScreenshotView`) y la sesión guiada en vivo.
/// La hora/batería no se imitan para no duplicar la barra de estado real en capturas.
struct DemoMobileBrowserChrome: View {
    /// URL ficticia en la barra (solo decorativa).
    var browserURLDisplay: String = "pacientes.saludplus.ejemplo.es"

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Image(systemName: "chevron.backward")
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                Image(systemName: "chevron.forward")
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.tertiary)

                HStack(spacing: 6) {
                    Image(systemName: "lock.fill")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(Color(red: 0.28, green: 0.55, blue: 0.35))
                    Text(browserURLDisplay)
                        .font(.caption.weight(.medium))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.75)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 9)
                .padding(.horizontal, 12)
                .background(Color(uiColor: .systemBackground), in: Capsule())
                .overlay(
                    Capsule()
                        .strokeBorder(Color(uiColor: .separator).opacity(0.55), lineWidth: 0.5)
                )

                Image(systemName: "square.on.square")
                    .font(.body)
                    .foregroundStyle(.primary)
                Image(systemName: "ellipsis.circle")
                    .font(.body)
                    .foregroundStyle(.primary)
            }
            .padding(.horizontal, 12)
            .padding(.top, 6)
            .padding(.bottom, 10)
        }
        .background(Color(uiColor: .secondarySystemGroupedBackground))
        .accessibilityElement(children: .ignore)
        .accessibilityHidden(true)
    }
}

/// Vista aislada para capturas: cromado genérico de navegador móvil + el mismo mock denso que en la sesión guiada.
struct MessyPortalFormScreenshotView: View {
    /// Paso del mock (`AppointmentMockFormState.configuration`); 0 = vacío y muy denso arriba.
    var mockStepIndex: Int = 0

    /// URL ficticia en la barra (solo decorativa).
    var browserURLDisplay: String = "pacientes.saludplus.ejemplo.es"

    var body: some View {
        VStack(spacing: 0) {
            DemoMobileBrowserChrome(browserURLDisplay: browserURLDisplay)

            AppointmentBookingDenseMockView(
                formState: AppointmentMockFormState.configuration(forStepIndex: mockStepIndex),
                focusSection: .topClutter,
                focusModeActive: false,
                scrollAnchor: .topClutter
            )
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(uiColor: .systemGroupedBackground))
    }
}

#Preview("Messy form — paso 0 (vacío)") {
    MessyPortalFormScreenshotView(mockStepIndex: 0)
}

#Preview("Messy form — paso medio (rellenado)") {
    MessyPortalFormScreenshotView(mockStepIndex: 4)
}
