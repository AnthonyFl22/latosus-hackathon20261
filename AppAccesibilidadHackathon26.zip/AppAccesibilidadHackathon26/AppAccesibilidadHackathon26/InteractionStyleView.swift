//
//  InteractionStyleView.swift
//  AppAccesibilidadHackathon26
//

import SwiftUI

struct InteractionStyleView: View {
    @Binding var selectedStyle: InteractionStyle?
    let onContinue: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("¿Cómo prefieres interactuar?")
                        .font(.title.bold())
                        .foregroundStyle(AppPalette.textPrimary)
                        .fixedSize(horizontal: false, vertical: true)
                        .accessibilityAddTraits(.isHeader)

                    Text("Elige el estilo de ayuda que prefieras.")
                        .font(.body)
                        .foregroundStyle(AppPalette.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .lineSpacing(4)
                }

                VStack(spacing: 12) {
                    ForEach(InteractionStyle.allCases) { style in
                        SelectableCardView(
                            icon: style.icon,
                            label: style.displayLabel,
                            subtitle: style.subtitle,
                            isSelected: selectedStyle == style
                        ) {
                            selectStyle(style)
                        }
                    }
                }
            }
            .padding(.horizontal, 24)
            .padding(.top, 32)
            .padding(.bottom, 24)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            VStack(spacing: 12) {
                Button(action: onContinue) {
                    Text("Continuar")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                }
                .buttonStyle(.borderedProminent)
                .tint(AppPalette.primary)
                .foregroundStyle(AppPalette.primaryOnPrimary)
                .disabled(selectedStyle == nil)
                .accessibilityHint(
                    selectedStyle == nil
                        ? "Selecciona un estilo para continuar"
                        : "Avanza para elegir qué ayudas quieres activar"
                )
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 16)
            .background(AppPalette.canvas)
        }
        .background(AppPalette.canvas)
    }

    private func selectStyle(_ style: InteractionStyle) {
        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
            selectedStyle = style
        }
    }
}

#Preview {
    InteractionStyleView(
        selectedStyle: .constant(.stepByStep),
        onContinue: {}
    )
}
