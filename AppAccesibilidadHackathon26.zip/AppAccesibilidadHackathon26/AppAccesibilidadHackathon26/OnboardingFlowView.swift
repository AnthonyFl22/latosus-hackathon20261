//
//  OnboardingFlowView.swift
//  AppAccesibilidadHackathon26
//

import SwiftUI

private enum OnboardingNavStep: String, Hashable, Codable {
    case interactionStyle
    case demoModeActivation
    case profileSummary
}

struct OnboardingFlowView: View {
    let onFinish: () -> Void

    @State private var path = NavigationPath()
    @State private var selectedDifficulties: Set<AccessibilityDifficulty> = []
    @State private var selectedStyle: InteractionStyle? = nil
    @State private var enabledDemoModes: Set<DemoSupportMode> = DemoSupportMode.elenaDefaults

    var body: some View {
        NavigationStack(path: $path) {
            DifficultiesSelectionView(
                selectedDifficulties: $selectedDifficulties,
                onContinue: {
                    path.append(OnboardingNavStep.interactionStyle)
                }
            )
            .navigationTitle("Personalización")
            .navigationBarTitleDisplayMode(.large)
            .navigationDestination(for: OnboardingNavStep.self) { step in
                switch step {
                case .interactionStyle:
                    InteractionStyleView(
                        selectedStyle: $selectedStyle,
                        onContinue: {
                            path.append(OnboardingNavStep.demoModeActivation)
                        }
                    )
                    .navigationTitle("Personalización")
                    .navigationBarTitleDisplayMode(.inline)
                case .demoModeActivation:
                    DemoModeActivationView(
                        enabledModes: $enabledDemoModes,
                        onContinue: {
                            path.append(OnboardingNavStep.profileSummary)
                        }
                    )
                    .navigationTitle("Personalización")
                    .navigationBarTitleDisplayMode(.inline)
                case .profileSummary:
                    ProfileSummaryView(
                        enabledModes: enabledDemoModes,
                        onFinish: onFinish
                    )
                    .navigationTitle("Personalización")
                    .navigationBarTitleDisplayMode(.inline)
                }
            }
        }
    }
}

#Preview {
    OnboardingFlowView(onFinish: {})
}
