//
//  AppPalette.swift
//  AppAccesibilidadHackathon26
//
//  Semantic colors: Assets.xcassets names use an `app` prefix to avoid clashing
//  with system APIs (e.g. SwiftUI.Color.primary). See ux-ui-design-language.mdc.
//

import SwiftUI

enum AppPalette {
    static let canvas = Color("appCanvas")
    static let surface = Color("appSurface")
    static let surfaceMuted = Color("appSurfaceMuted")
    static let primary = Color("appPrimary")
    static let primaryOnPrimary = Color("appPrimaryOnPrimary")
    static let primaryMuted = Color("appPrimaryMuted")
    static let textPrimary = Color("appTextPrimary")
    static let textSecondary = Color("appTextSecondary")
    static let border = Color("appBorder")
    static let accent = Color("appAccent")
    static let success = Color("appSuccess")
    static let warning = Color("appWarning")
    static let destructive = Color("appDestructive")
}
