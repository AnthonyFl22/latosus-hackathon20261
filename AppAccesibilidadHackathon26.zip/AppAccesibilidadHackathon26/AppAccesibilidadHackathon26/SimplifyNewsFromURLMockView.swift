//
//  SimplifyNewsFromURLMockView.swift
//  AppAccesibilidadHackathon26
//
//  Mock de “Simplify This” para artículos por URL (y simulación de documento).
//  No enlazada a AppRootView; úsala desde Preview como MessyMapsAppScreenshotView.
//

import SwiftUI

private enum SimplifyNewsPhase: Equatable {
    case input
    case preparing
    case result
}

private enum SimplifyInputTab: String, CaseIterable, Identifiable {
    case link = "Enlace"
    case document = "Documento"

    var id: String { rawValue }
}

// MARK: - Asistente (guion por fase / paso)

private struct NewsAssistantBeat {
    let summary: String
    let highlight: String
    let voiceScript: String
}

private enum NewsAssistantCopy {
    static let input = NewsAssistantBeat(
        summary: "Soy tu asistente de lectura. No juzgo si el artículo es difícil: lo reorganizo para ti.",
        highlight: "Pega un enlace con https y usa el botón principal al final de la pantalla.",
        voiceScript:
            "Hola. En esta demostración yo preparo una versión más clara del artículo. Pega la dirección web y pulsa el botón principal al final de la pantalla: va debajo del asistente, así no queda tapado. Espera unos segundos y después te iré explicando cada parte en voz alta si lo deseas."
    )

    static let preparing = NewsAssistantBeat(
        summary: "Estoy ordenando ideas como haría un editor: quitar ruido y dejar lo esencial.",
        highlight: "Casi listo: detecto términos confusos y preparo un mini diccionario.",
        voiceScript:
            "Un momento. Estoy simulando el trabajo de simplificar el texto: resumen, puntos clave y palabras difíciles explicadas. En la app real aquí conectaríamos con el artículo de verdad."
    )

    static let resultBeats: [NewsAssistantBeat] = [
        NewsAssistantBeat(
            summary: "He dejado el titular en lenguaje directo y te marco de dónde salió el texto.",
            highlight: "Empieza por el título: ya no está lleno de siglas ni subrayados intimidantes.",
            voiceScript:
                "Aquí tienes el tema en limpio: normas europeas sobre inteligencia artificial. Abajo verás de qué enlace o archivo simulado viene. No es magia: en la demo el texto es de ejemplo, pero así se vería una lectura amable."
        ),
        NewsAssistantBeat(
            summary: "Esta caja resume el artículo largo en un solo párrafo que puedes leer en un minuto.",
            highlight: "Si solo quieres lo básico, quédate con “En pocas palabras”.",
            voiceScript:
                "En pocas palabras: Europa fija reglas para que la inteligencia artificial sea más segura. Según el riesgo, las empresas tendrán que cumplir más o menos controles. Es el núcleo del artículo original, sin rodeos."
        ),
        NewsAssistantBeat(
            summary: "Cada tarjeta es un bloque del artículo: aprobación, alto riesgo, transparencia y sanciones.",
            highlight: "Léelas en orden: cuentan la historia completa sin saltos.",
            voiceScript:
                "La sección qué cuenta el artículo divide el tema en cuatro piezas: qué se aprobó, qué pasa en sectores sensibles como salud o justicia, la obligación de avisar cuando un contenido es generado por máquinas, y las multas para quien no cumpla."
        ),
        NewsAssistantBeat(
            summary: "Aquí conecto el texto con tu día a día: por qué te puede afectar como persona usuaria.",
            highlight: "Si algo te suena lejano, esta parte lo acerca a apps y trámites cotidianos.",
            voiceScript:
                "Por qué te puede importar: si usas servicios en línea o te preocupan datos y privacidad, estas normas cambian lo que puedes esperar de empresas y administraciones en los próximos años."
        ),
        NewsAssistantBeat(
            summary: "El glosario traduce términos técnicos sin menospreciar: es apoyo, no un examen.",
            highlight: "Toca Escuchar en cada palabra si quieres repasarla con calma.",
            voiceScript:
                "En palabras que suelen confundir encontrarás expresiones como inteligencia artificial de propósito general y evaluación de conformidad. Son las piezas que suelen hacer densos los textos legales; aquí van explicadas con sencillez."
        ),
        NewsAssistantBeat(
            summary: "Ya recorriste la lectura asistida. Puedes volver a escuchar cualquier parte con los botones.",
            highlight: "¿Otro artículo? Usa el icono circular o “Empezar otra lectura” en el asistente.",
            voiceScript:
                "Has terminado el recorrido guiado de esta demo. Puedes usar Escuchar para repetir o cambiar la velocidad. Para leer otra noticia, pulsa el icono de flecha circular junto al asistente o el botón Empezar otra lectura dentro del panel. Gracias por probar esta experiencia."
        )
    ]
}

/// Contenido de demostración: tema complejo explicado en lenguaje claro (hardcoded).
private enum MockSimplifiedArticle {
    static let title = "Normas nuevas sobre inteligencia artificial en la Unión Europea"
    static let subtitle = "Lectura sencilla a partir de un artículo denso. Esto es una simulación: no se conecta a internet."

    static let summary =
        "Europa está definiendo reglas para que los sistemas de inteligencia artificial sean más seguros y justos. Las empresas tendrán obligaciones distintas según el riesgo que tenga cada uso."

    static let whatHappened: [(String, String)] = [
        ("Qué se aprobó", "Un marco legal que clasifica usos de IA según el daño que podrían causar a las personas."),
        ("Alto riesgo", "En sectores como salud, educación o justicia, los sistemas deberán cumplir exigencias fuertes antes de usarse."),
        ("Transparencia", "Los contenidos generados por IA deberán poder identificarse cuando afecten a ciudadanos."),
        ("Multas", "Quien incumpla puede enfrentar sanciones importantes; sirve como incentivo para tomarse las reglas en serio.")
    ]

    static let whyItMatters =
        "Si usas servicios digitales, trabajas con datos o te preocupa la privacidad, estas normas cambian qué puedes esperar de las empresas y de las administraciones en los próximos años."

    static let glossary: [(String, String)] = [
        ("IA de propósito general", "Modelos versátiles que sirven para muchas tareas; las reglas especiales buscan que no se usen de forma opaca o peligrosa."),
        ("Evaluación de conformidad", "Comprobaciones y documentación para demostrar que un sistema cumple lo exigido antes de comercializarlo o usarlo en ciertos ámbitos.")
    ]
}

// MARK: - Vista principal

struct SimplifyNewsFromURLMockView: View {
    @StateObject private var speech = GuidedSpeechController()

    @State private var phase: SimplifyNewsPhase = .input
    @State private var inputTab: SimplifyInputTab = .link
    @State private var urlText: String = "https://ejemplo-noticias.eu/union-europea-ia-reglamento-2026"
    @State private var sourceLabel: String = ""

    @State private var showDocumentDemoHint = false
    /// Colapsado por defecto: el botón principal queda descubierto y el asistente es opcional.
    @State private var bubbleExpanded = false
    @State private var resultExplanationStep = 0

    private var resultBeats: [NewsAssistantBeat] { NewsAssistantCopy.resultBeats }

    private var currentBeat: NewsAssistantBeat {
        switch phase {
        case .input:
            return NewsAssistantCopy.input
        case .preparing:
            return NewsAssistantCopy.preparing
        case .result:
            let idx = min(max(resultExplanationStep, 0), resultBeats.count - 1)
            return resultBeats[idx]
        }
    }

    private var isLastResultBeat: Bool {
        phase == .result && resultExplanationStep >= resultBeats.count - 1
    }

    var body: some View {
        Group {
            switch phase {
            case .input:
                inputScreen
            case .preparing:
                preparingScreen
            case .result:
                resultScreen
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(AppPalette.canvas)
        .safeAreaInset(edge: .bottom, spacing: 0) {
            bottomChrome
        }
        .animation(.easeInOut(duration: 0.25), value: phase)
        .animation(.spring(response: 0.32, dampingFraction: 0.86), value: bubbleExpanded)
        .alert("Demo sin archivo real", isPresented: $showDocumentDemoHint) {
            Button("Entendido", role: .cancel) {}
        } message: {
            Text("Pronto podrás adjuntar un PDF u otro documento. En esta demostración solo simulamos el flujo: usa la pestaña Enlace o el botón de simulación.")
        }
        .onAppear {
            if phase == .input, !speech.isMuted {
                speech.speak(NewsAssistantCopy.input.voiceScript)
            }
        }
        .onChange(of: phase) { _, newPhase in
            speech.stopSpeaking()
            switch newPhase {
            case .input:
                resultExplanationStep = 0
                if !speech.isMuted {
                    speech.speak(NewsAssistantCopy.input.voiceScript)
                }
            case .preparing:
                if !speech.isMuted {
                    speech.speak(NewsAssistantCopy.preparing.voiceScript)
                }
            case .result:
                resultExplanationStep = 0
                bubbleExpanded = false
                if !speech.isMuted {
                    speech.speak(resultBeats[0].voiceScript)
                }
            }
        }
        .onChange(of: resultExplanationStep) { _, _ in
            guard phase == .result else { return }
            speech.stopSpeaking()
            if !speech.isMuted {
                let idx = min(max(resultExplanationStep, 0), resultBeats.count - 1)
                speech.speak(resultBeats[idx].voiceScript)
            }
        }
        .onChange(of: speech.isMuted) { _, muted in
            if muted {
                speech.stopSpeaking()
            } else {
                speech.speak(currentBeat.voiceScript)
            }
        }
        .onDisappear {
            speech.stopSpeaking()
        }
    }

    // MARK: - Barra inferior: asistente (resultado) o asistente + crear versión (entrada)

    private var bottomChrome: some View {
        VStack(spacing: 0) {
            assistantDock

            if phase == .input {
                Rectangle()
                    .fill(AppPalette.border)
                    .frame(height: 1)
                    .accessibilityHidden(true)

                createSimplifiedButton
                    .padding(.horizontal, 20)
                    .padding(.top, 12)
                    .padding(.bottom, 16)
            } else if phase == .preparing {
                Color.clear
                    .frame(height: 12)
                    .accessibilityHidden(true)
            } else {
                Color.clear
                    .frame(height: 10)
                    .accessibilityHidden(true)
            }
        }
        .background(AppPalette.canvas)
    }

    private var assistantDock: some View {
        VStack(alignment: .leading, spacing: 0) {
            if bubbleExpanded {
                ScrollView {
                    expandedAssistantBubble
                }
                .frame(maxHeight: assistantPanelMaxExpandedHeight)
                .transition(.opacity.combined(with: .move(edge: .bottom)))
            } else {
                collapsedAssistantChip
                    .transition(.opacity)
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, phase == .result ? 8 : 8)
        .padding(.bottom, phase == .result ? 10 : 4)
    }

    private var assistantPanelMaxExpandedHeight: CGFloat {
        phase == .result ? 420 : 340
    }

    private func restartReadingFromAssistant() {
        speech.stopSpeaking()
        phase = .input
    }

    private var collapsedAssistantChip: some View {
        HStack(alignment: .center, spacing: 12) {
            Button {
                bubbleExpanded = true
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: "sparkles")
                        .font(phase == .result ? .title2 : .title3)
                        .foregroundStyle(AppPalette.primary)
                        .accessibilityHidden(true)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(assistantPhaseCaption)
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(AppPalette.textSecondary)
                        Text(currentBeat.highlight)
                            .font(phase == .result ? .subheadline.weight(.medium) : .subheadline.weight(.medium))
                            .foregroundStyle(AppPalette.textPrimary)
                            .lineLimit(2)
                            .multilineTextAlignment(.leading)
                            .minimumScaleFactor(0.92)
                    }
                    Spacer(minLength: 8)
                    Image(systemName: "chevron.up")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(AppPalette.textSecondary)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, phase == .result ? 16 : 14)
                .frame(maxWidth: .infinity, alignment: .leading)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityHint("Abre el panel del asistente con voz y controles.")

            if phase == .result {
                Button(action: restartReadingFromAssistant) {
                    Image(systemName: "arrow.counterclockwise.circle.fill")
                        .font(.system(size: 34))
                        .symbolRenderingMode(.hierarchical)
                        .foregroundStyle(AppPalette.primary)
                        .frame(width: 48, height: 48)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Empezar otra lectura")
                .accessibilityHint("Vuelve a la pantalla para pegar otro enlace o simular un documento.")
            }
        }
        .padding(.leading, phase == .result ? 4 : 0)
        .padding(.trailing, phase == .result ? 8 : 0)
        .background(AppPalette.surface)
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .shadow(color: .black.opacity(0.08), radius: 12, y: 4)
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .strokeBorder(AppPalette.border, lineWidth: 1)
        )
    }

    private var assistantPhaseCaption: String {
        switch phase {
        case .input: return "Lectura asistida"
        case .preparing: return "Organizando…"
        case .result: return "Explicación \(resultExplanationStep + 1) de \(resultBeats.count)"
        }
    }

    @ViewBuilder
    private var expandedAssistantBubble: some View {
        if phase == .result {
            expandedResultAssistantPanel
        } else {
            expandedDefaultAssistantPanel
        }
    }

    /// Entrada y preparación: panel cómodo con todo el texto de ayuda.
    private var expandedDefaultAssistantPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            assistantPanelHeader

            Text(currentBeat.summary)
                .font(.subheadline)
                .foregroundStyle(AppPalette.textSecondary)
                .fixedSize(horizontal: false, vertical: true)

            Text(currentBeat.highlight)
                .font(.body.weight(.semibold))
                .foregroundStyle(AppPalette.primary)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)

            assistantControlGridInputPreparing
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppPalette.surface)
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .shadow(color: .black.opacity(0.06), radius: 8, y: 3)
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .strokeBorder(AppPalette.border, lineWidth: 1)
        )
    }

    /// Resultado: panel amplio; “Empezar otra lectura” al final (sin barra inferior extra).
    private var expandedResultAssistantPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .center, spacing: 10) {
                Label("Asistente", systemImage: "person.wave.2.fill")
                    .font(.headline)
                    .foregroundStyle(AppPalette.textPrimary)
                Spacer(minLength: 0)
                Text("\(resultExplanationStep + 1) / \(resultBeats.count)")
                    .font(.subheadline.weight(.bold))
                    .monospacedDigit()
                    .foregroundStyle(AppPalette.textSecondary)
                    .accessibilityLabel("Paso \(resultExplanationStep + 1) de \(resultBeats.count)")
                Button {
                    bubbleExpanded = false
                } label: {
                    Image(systemName: "chevron.down.circle.fill")
                        .font(.title2)
                        .symbolRenderingMode(.hierarchical)
                        .foregroundStyle(AppPalette.textSecondary)
                }
                .accessibilityLabel("Minimizar asistente")
            }

            ProgressView(value: Double(resultExplanationStep + 1), total: Double(resultBeats.count))
                .tint(AppPalette.primary)
                .scaleEffect(x: 1, y: 1.15, anchor: .center)

            Text(currentBeat.highlight)
                .font(.body.weight(.semibold))
                .foregroundStyle(AppPalette.primary)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)

            Text(currentBeat.summary)
                .font(.subheadline)
                .foregroundStyle(AppPalette.textSecondary)
                .fixedSize(horizontal: false, vertical: true)
                .lineSpacing(3)

            HStack(spacing: 10) {
                Button {
                    speech.speak(currentBeat.voiceScript)
                } label: {
                    Label("Escuchar", systemImage: "speaker.wave.2.fill")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                }
                .buttonStyle(.borderedProminent)
                .tint(AppPalette.primary)
                .foregroundStyle(AppPalette.primaryOnPrimary)
                .disabled(speech.isMuted)
                .accessibilityHint(
                    speech.isMuted
                        ? "Activa el sonido para escuchar la explicación."
                        : "Lee en voz alta este paso del artículo."
                )

                Button {
                    speech.isMuted.toggle()
                } label: {
                    Image(systemName: speech.isMuted ? "speaker.slash.fill" : "speaker.fill")
                        .font(.title3.weight(.semibold))
                        .frame(width: 52, height: 52)
                }
                .buttonStyle(.bordered)
                .tint(AppPalette.primary)
                .accessibilityLabel(speech.isMuted ? "Activar sonido" : "Silenciar")
                .accessibilityHint("Activa o desactiva la voz del asistente.")

                Menu {
                    Button {
                        speech.fastRate.toggle()
                    } label: {
                        Label(
                            speech.fastRate ? "Usar velocidad normal" : "Leer más rápido",
                            systemImage: "hare.fill"
                        )
                    }
                    Button(action: restartReadingFromAssistant) {
                        Label("Empezar otra lectura", systemImage: "arrow.counterclockwise")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                        .font(.title2)
                        .frame(width: 52, height: 52)
                        .foregroundStyle(AppPalette.primary)
                }
                .accessibilityLabel("Más opciones")
                .accessibilityHint("Velocidad de voz u otra lectura.")
            }

            HStack(spacing: 10) {
                Button {
                    speech.stopSpeaking()
                    resultExplanationStep = max(0, resultExplanationStep - 1)
                } label: {
                    Label("Anterior", systemImage: "chevron.left")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                }
                .buttonStyle(.bordered)
                .tint(AppPalette.primary)
                .disabled(resultExplanationStep <= 0)

                Button {
                    speech.stopSpeaking()
                    resultExplanationStep = min(resultBeats.count - 1, resultExplanationStep + 1)
                } label: {
                    Label(isLastResultBeat ? "Fin" : "Siguiente", systemImage: "chevron.right")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                }
                .buttonStyle(.bordered)
                .tint(AppPalette.primary)
                .disabled(isLastResultBeat)
                .accessibilityHint(
                    isLastResultBeat
                        ? "Último paso. Usa Escuchar para repetir."
                        : "Siguiente parte del artículo."
                )
            }

            Button(action: restartReadingFromAssistant) {
                Label("Empezar otra lectura", systemImage: "arrow.counterclockwise")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
            }
            .buttonStyle(.bordered)
            .tint(AppPalette.textSecondary)
            .accessibilityHint("Vuelve a pegar un enlace o simular un documento.")
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppPalette.surface)
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .shadow(color: .black.opacity(0.06), radius: 10, y: 4)
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .strokeBorder(AppPalette.border, lineWidth: 1)
        )
    }

    private var assistantPanelHeader: some View {
        HStack {
            Label("Asistente", systemImage: "person.wave.2.fill")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(AppPalette.textPrimary)
            Spacer(minLength: 0)
            Button {
                bubbleExpanded = false
            } label: {
                Image(systemName: "chevron.down.circle.fill")
                    .font(.title3)
                    .symbolRenderingMode(.hierarchical)
                    .foregroundStyle(AppPalette.textSecondary)
            }
            .accessibilityLabel("Minimizar asistente")
        }
    }

    private var assistantControlGridInputPreparing: some View {
        VStack(spacing: 10) {
            HStack(spacing: 10) {
                Button {
                    speech.speak(currentBeat.voiceScript)
                } label: {
                    Label("Escuchar", systemImage: "speaker.wave.2.fill")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                }
                .buttonStyle(.borderedProminent)
                .tint(AppPalette.primary)
                .foregroundStyle(AppPalette.primaryOnPrimary)
                .disabled(speech.isMuted)
                .accessibilityHint(
                    speech.isMuted
                        ? "Activa el sonido para escuchar la explicación."
                        : "Lee en voz alta la explicación de esta pantalla o paso."
                )

                Button {
                    speech.isMuted.toggle()
                } label: {
                    Label(speech.isMuted ? "Sonido" : "Silenciar", systemImage: speech.isMuted ? "speaker.slash.fill" : "speaker.fill")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                }
                .buttonStyle(.bordered)
                .tint(AppPalette.primary)
                .accessibilityHint("Activa o desactiva la voz del asistente.")
            }

            Button {
                speech.fastRate.toggle()
            } label: {
                Label(speech.fastRate ? "Velocidad normal" : "Más rápido", systemImage: "hare.fill")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
            }
            .buttonStyle(.bordered)
            .tint(AppPalette.primary)
            .accessibilityHint("Cambia la velocidad de la voz.")
        }
    }

    // MARK: - Input

    private var inputScreen: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                compactInputIntro

                Picker("Tipo de contenido", selection: $inputTab) {
                    ForEach(SimplifyInputTab.allCases) { tab in
                        Text(tab.rawValue).tag(tab)
                    }
                }
                .pickerStyle(.segmented)
                .accessibilityLabel("Tipo de contenido: enlace o documento")

                if inputTab == .link {
                    linkFields
                } else {
                    documentFields
                }

                // demoDisclaimer
            }
            .padding(.horizontal, 24)
            .padding(.top, 16)
            .padding(.bottom, 24)
        }
    }

    /// Una sola tarjeta de cabecera (antes: hero + fila de señales + título duplicado).
    private var compactInputIntro: some View {
        HStack(alignment: .top, spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [AppPalette.primaryMuted, AppPalette.surface],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 52, height: 52)
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .strokeBorder(AppPalette.border, lineWidth: 1)
                    )
                Image(systemName: "wand.and.stars.inverse")
                    .font(.system(size: 24))
                    .foregroundStyle(AppPalette.primary)
                    .accessibilityHidden(true)
            }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("Lectura asistida")

            VStack(alignment: .leading, spacing: 8) {
                Text("Simplificar una lectura")
                    .font(.title2.bold())
                    .foregroundStyle(AppPalette.textPrimary)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityAddTraits(.isHeader)

                Text("Pega un enlace; obtendrás un texto más corto. El asistente en la barra inferior puede leerte la guía cuando quieras.")
                    .font(.subheadline)
                    .foregroundStyle(AppPalette.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .lineSpacing(3)

                Text("Voz en español · tú marcas el ritmo")
                    .font(.caption.weight(.medium))
                    .foregroundStyle(AppPalette.textSecondary)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppPalette.surface)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .strokeBorder(AppPalette.border, lineWidth: 1)
        )
    }

    private var linkFields: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Dirección del artículo")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(AppPalette.textPrimary)

            TextField("https://…", text: $urlText)
                .textContentType(.URL)
                .keyboardType(.URL)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .padding(16)
                .background(AppPalette.surface)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .strokeBorder(AppPalette.border, lineWidth: 1)
                )
                .accessibilityLabel("Dirección web del artículo")
        }
    }

    private var documentFields: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Sube un documento para obtener una lectura accesible. En la demo puedes simular una subida.")
                .font(.body)
                .foregroundStyle(AppPalette.textSecondary)
                .fixedSize(horizontal: false, vertical: true)

            Button {
                showDocumentDemoHint = true
            } label: {
                Label("Elegir archivo del dispositivo", systemImage: "doc.badge.arrow.up")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
            }
            .buttonStyle(.bordered)
            .tint(AppPalette.primary)

            Button {
                startPreparing(source: .documentMock(name: "informe-politica-digital.pdf"))
            } label: {
                Label("Simular documento ya subido", systemImage: "doc.text.fill")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
            }
            .buttonStyle(.borderedProminent)
            .tint(AppPalette.primary)
            .foregroundStyle(AppPalette.primaryOnPrimary)
            .accessibilityHint("Salta la selección real y muestra el mismo resumen de demostración que con un enlace.")
        }
    }

    private var demoDisclaimer: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "info.circle.fill")
                .font(.title3)
                .foregroundStyle(AppPalette.accent)
                .accessibilityHidden(true)
            Text("Demo: no se abre el enlace; el resumen es de ejemplo.")
                .font(.caption)
                .foregroundStyle(AppPalette.textSecondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppPalette.surfaceMuted)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(AppPalette.border, lineWidth: 1)
        )
        .accessibilityElement(children: .combine)
    }

    private var createSimplifiedButton: some View {
        Button {
            startPreparing(source: .url(urlText))
        } label: {
            Label("Crear versión simplificada", systemImage: "wand.and.stars")
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
        }
        .buttonStyle(.borderedProminent)
        .tint(AppPalette.primary)
        .foregroundStyle(AppPalette.primaryOnPrimary)
        .disabled(inputTab == .document || !canSubmitURL)
        .accessibilityHint(
            inputTab == .document
                ? "Cambia a la pestaña Enlace o usa simular documento en la sección de archivo."
                : "Genera la lectura sencilla de demostración tras una breve espera. Está en la barra inferior, debajo del asistente."
        )
    }

    private var canSubmitURL: Bool {
        let t = urlText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return false }
        return t.lowercased().hasPrefix("http://") || t.lowercased().hasPrefix("https://")
    }

    private enum PreparedSource {
        case url(String)
        case documentMock(name: String)
    }

    private func startPreparing(source: PreparedSource) {
        switch source {
        case .url(let s):
            sourceLabel = s.trimmingCharacters(in: .whitespacesAndNewlines)
        case .documentMock(let name):
            sourceLabel = name
        }
        phase = .preparing
        Task {
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            await MainActor.run {
                phase = .result
            }
        }
    }

    // MARK: - Preparing

    private var preparingScreen: some View {
        VStack(spacing: 24) {
            Spacer(minLength: 0)

            ZStack {
                Circle()
                    .fill(AppPalette.primaryMuted.opacity(0.45))
                    .frame(width: 100, height: 100)
                ProgressView()
                    .scaleEffect(1.25)
                    .tint(AppPalette.primary)
            }
            .accessibilityElement(children: .combine)
            .accessibilityLabel("Preparando lectura")

            VStack(spacing: 10) {
                Text("Preparando tu lectura sencilla")
                    .font(.title2.weight(.semibold))
                    .foregroundStyle(AppPalette.textPrimary)
                    .multilineTextAlignment(.center)
                    .accessibilityAddTraits(.isHeader)

                Text("Resumen, bloques claros y términos explicados. Solo unos segundos.")
                    .font(.subheadline)
                    .foregroundStyle(AppPalette.textSecondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 28)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(.horizontal, 24)
    }

    // MARK: - Result

    /// Alineado con `resultExplanationStep` (0…5) para `ScrollViewReader.scrollTo`.
    private enum ResultArticleScrollID: Int, Hashable {
        case title = 0
        case inShort = 1
        case whatHappened = 2
        case whyMatters = 3
        case glossary = 4
        case done = 5
    }

    private var resultScreen: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Group {
                        articleHeaderBlock
                            .padding(16)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(AppPalette.surface)
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .strokeBorder(AppPalette.border, lineWidth: 1)
                            )
                            .modifier(ResultFocusModifier(step: 0, current: resultExplanationStep, cornerRadius: 16))
                    }
                    .id(ResultArticleScrollID.title)

                    Group {
                        VStack(alignment: .leading, spacing: 12) {
                            sectionTitle("En pocas palabras")
                            Text(MockSimplifiedArticle.summary)
                                .font(.body)
                                .foregroundStyle(AppPalette.textPrimary)
                                .fixedSize(horizontal: false, vertical: true)
                                .lineSpacing(4)
                        }
                        .padding(18)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(AppPalette.surface)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .strokeBorder(AppPalette.border, lineWidth: 1)
                        )
                    }
                    .modifier(ResultFocusModifier(step: 1, current: resultExplanationStep, cornerRadius: 16))
                    .id(ResultArticleScrollID.inShort)

                    Group {
                        VStack(alignment: .leading, spacing: 14) {
                            sectionTitle("Qué cuenta el artículo")
                            ForEach(Array(MockSimplifiedArticle.whatHappened.enumerated()), id: \.offset) { _, item in
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(item.0)
                                        .font(.subheadline.weight(.semibold))
                                        .foregroundStyle(AppPalette.textPrimary)
                                    Text(item.1)
                                        .font(.body)
                                        .foregroundStyle(AppPalette.textSecondary)
                                        .fixedSize(horizontal: false, vertical: true)
                                        .lineSpacing(3)
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(14)
                                .background(AppPalette.surfaceMuted)
                                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                            }
                        }
                    }
                    .modifier(ResultFocusModifier(step: 2, current: resultExplanationStep, cornerRadius: 16))
                    .id(ResultArticleScrollID.whatHappened)

                    Group {
                        VStack(alignment: .leading, spacing: 10) {
                            sectionTitle("Por qué te puede importar")
                            Text(MockSimplifiedArticle.whyItMatters)
                                .font(.body)
                                .foregroundStyle(AppPalette.textPrimary)
                                .fixedSize(horizontal: false, vertical: true)
                                .lineSpacing(4)
                        }
                        .padding(18)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(AppPalette.primaryMuted)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .strokeBorder(AppPalette.border, lineWidth: 1)
                        )
                    }
                    .modifier(ResultFocusModifier(step: 3, current: resultExplanationStep, cornerRadius: 16))
                    .id(ResultArticleScrollID.whyMatters)

                    Group {
                        VStack(alignment: .leading, spacing: 12) {
                            sectionTitle("Palabras que suelen confundir")
                            ForEach(Array(MockSimplifiedArticle.glossary.enumerated()), id: \.offset) { _, row in
                                HStack(alignment: .top, spacing: 10) {
                                    Image(systemName: "text.book.closed")
                                        .font(.body)
                                        .foregroundStyle(AppPalette.primary)
                                        .frame(width: 24, alignment: .center)
                                        .accessibilityHidden(true)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(row.0)
                                            .font(.subheadline.weight(.semibold))
                                            .foregroundStyle(AppPalette.textPrimary)
                                        Text(row.1)
                                            .font(.footnote)
                                            .foregroundStyle(AppPalette.textSecondary)
                                            .fixedSize(horizontal: false, vertical: true)
                                    }
                                }
                                .padding(14)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(AppPalette.surface)
                                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                                        .strokeBorder(AppPalette.border, lineWidth: 1)
                                )
                            }
                        }
                    }
                    .modifier(ResultFocusModifier(step: 4, current: resultExplanationStep, cornerRadius: 16))
                    .id(ResultArticleScrollID.glossary)

                    summaryCard
                        .modifier(ResultFocusModifier(step: 5, current: resultExplanationStep, cornerRadius: 14))
                        .id(ResultArticleScrollID.done)
                }
                .padding(.horizontal, 24)
                .padding(.top, 12)
                .padding(.bottom, 28)
            }
            .onAppear {
                scrollResultArticle(to: resultExplanationStep, proxy: proxy)
            }
            .onChange(of: resultExplanationStep) { _, newStep in
                scrollResultArticle(to: newStep, proxy: proxy)
            }
        }
    }

    private func scrollResultArticle(to step: Int, proxy: ScrollViewProxy) {
        let raw = min(max(step, 0), 5)
        guard let anchor = ResultArticleScrollID(rawValue: raw) else { return }
        withAnimation(.easeInOut(duration: 0.45)) {
            proxy.scrollTo(anchor, anchor: .top)
        }
    }

    private var articleHeaderBlock: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(sourceLine, systemImage: sourceIcon)
                .font(.subheadline.weight(.medium))
                .foregroundStyle(AppPalette.textSecondary)
                .fixedSize(horizontal: false, vertical: true)

            Text(MockSimplifiedArticle.title)
                .font(.title.bold())
                .foregroundStyle(AppPalette.textPrimary)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)

            Text(MockSimplifiedArticle.subtitle)
                .font(.footnote)
                .foregroundStyle(AppPalette.textSecondary)
                .fixedSize(horizontal: false, vertical: true)

            Text("Lectura aprox. 3 min · texto de demostración")
                .font(.caption.weight(.medium))
                .foregroundStyle(AppPalette.textSecondary)
        }
    }

    private var sourceIcon: String {
        let s = sourceLabel.lowercased()
        if s.hasPrefix("http://") || s.hasPrefix("https://") {
            return "link"
        }
        return "doc.richtext"
    }

    private var sourceLine: String {
        if sourceLabel.lowercased().hasPrefix("http") {
            return "Fuente: \(sourceLabel)"
        }
        return "Archivo simulado: \(sourceLabel)"
    }

    private var summaryCard: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "checkmark.seal.fill")
                .font(.title2)
                .foregroundStyle(AppPalette.success)
                .accessibilityHidden(true)
            Text("Listo. Usa el asistente en la barra inferior para oír cada parte. Para otro artículo, el icono de flecha circular o “Empezar otra lectura” en el panel.")
                .font(.footnote)
                .foregroundStyle(AppPalette.textPrimary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppPalette.surface)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(AppPalette.success.opacity(0.45), lineWidth: 2)
        )
        .accessibilityElement(children: .combine)
    }

    private func sectionTitle(_ text: String) -> some View {
        Text(text)
            .font(.headline)
            .foregroundStyle(AppPalette.textPrimary)
            .accessibilityAddTraits(.isHeader)
    }

}

// MARK: - Foco visual alineado al paso del asistente

private struct ResultFocusModifier: ViewModifier {
    let step: Int
    let current: Int
    var cornerRadius: CGFloat = 16

    func body(content: Content) -> some View {
        content
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .strokeBorder(
                        current == step ? AppPalette.primary : Color.clear,
                        lineWidth: current == step ? 2.5 : 0
                    )
            )
            .animation(.easeInOut(duration: 0.2), value: current)
    }
}

#Preview("Simplify This — noticia por URL (mock)") {
    SimplifyNewsFromURLMockView()
}
