//
//  GuidedSessionStartView.swift
//  AppAccesibilidadHackathon26
//

import SwiftUI

private enum GuidedSessionSourceOption: String, CaseIterable, Identifiable, Hashable {
    case demoAppointment
    case uploadCapture
    case openFormExample

    var id: String { rawValue }

    var displayTitle: String {
        switch self {
        case .demoAppointment:
            return "Usar pantalla de demo: Agendar cita"
        case .uploadCapture:
            return "Subir captura"
        case .openFormExample:
            return "Abrir ejemplo de formulario"
        }
    }

    var icon: String {
        switch self {
        case .demoAppointment:
            return "calendar.badge.clock"
        case .uploadCapture:
            return "photo.badge.arrow.up"
        case .openFormExample:
            return "doc.text.fill"
        }
    }
}

struct GuidedSessionStartView: View {
    @Binding var path: NavigationPath

    @State private var selectedOption: GuidedSessionSourceOption = .demoAppointment

    private var canContinue: Bool {
        selectedOption == .demoAppointment
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                Text("Iniciar acompañamiento")
                    .font(.title.bold())
                    .foregroundStyle(AppPalette.textPrimary)
                    .fixedSize(horizontal: false, vertical: true)
                    .accessibilityAddTraits(.isHeader)

                Text(
                    "Cuando compartes una pantalla, puedo ayudarte a entenderla, resaltar lo importante y guiarte paso a paso."
                )
                .font(.body)
                .foregroundStyle(AppPalette.textSecondary)
                .fixedSize(horizontal: false, vertical: true)
                .lineSpacing(4)

                VStack(spacing: 12) {
                    ForEach(GuidedSessionSourceOption.allCases) { option in
                        SelectableCardView(
                            icon: option.icon,
                            label: option.displayTitle,
                            isSelected: selectedOption == option
                        ) {
                            selectedOption = option
                        }
                        .accessibilityHint(accessibilityHint(for: option))
                    }
                }
                .accessibilityElement(children: .contain)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 24)
            .padding(.top, 16)
            .padding(.bottom, 8)
        }
        .background(AppPalette.canvas)
        .navigationTitle("Guíame")
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaInset(edge: .bottom, spacing: 0) {
            VStack(spacing: 0) {
                Button(action: continueTapped) {
                    Text("Continuar")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                }
                .buttonStyle(.borderedProminent)
                .tint(AppPalette.primary)
                .foregroundStyle(AppPalette.primaryOnPrimary)
                .disabled(!canContinue)
                .accessibilityHint(
                    canContinue
                        ? "Abre la pantalla de ejemplo para agendar una cita"
                        : "Para esta demo, elige la pantalla de ejemplo de agendar cita."
                )
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 16)
            .background(AppPalette.canvas)
        }
    }

    private func continueTapped() {
        guard canContinue else { return }
        path.append(HomeRoute.guidedAppointmentDemo)
    }

    private func accessibilityHint(for option: GuidedSessionSourceOption) -> String {
        switch option {
        case .demoAppointment:
            return "Opción recomendada para la demo"
        case .uploadCapture:
            return "Visible en la demo; aún no está disponible."
        case .openFormExample:
            return "Opcional en la demo; aún no está disponible."
        }
    }
}

#Preview("Start") {
    struct GuidedSessionStartPreviewHost: View {
        @State private var path = NavigationPath()

        var body: some View {
            NavigationStack(path: $path) {
                GuidedSessionStartView(path: $path)
                    .navigationDestination(for: HomeRoute.self) { route in
                        switch route {
                        case .guidedAppointmentDemo:
                            GuidedSessionLiveView()
                        default:
                            EmptyView()
                        }
                    }
            }
        }
    }
    return GuidedSessionStartPreviewHost()
}
