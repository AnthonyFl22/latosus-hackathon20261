//
//  HomeModePlaceholderViews.swift
//  AppAccesibilidadHackathon26
//

import SwiftUI

enum HomeRoute: Hashable {
    /// Screen 7 — start guided session (source selection).
    case guidedSession
    /// After Continuar with demo appointment selected (session UI TBD).
    case guidedAppointmentDemo
    case focusMode
    /// Pantalla 10 — `fromGuidedSession` drives copy/hints when returning to pantalla 9.
    case simplify(fromGuidedSession: Bool)
}

struct HomeModePlaceholderView: View {
    let route: HomeRoute

    @Environment(\.dismiss) private var dismiss

    private var title: String {
        switch route {
        case .guidedSession, .guidedAppointmentDemo:
            return "Guíame"
        case .focusMode: return "Modo foco"
        case .simplify(_): return "Simplificar" // unused: simplify opens SimplifiedTaskView
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Esta parte de la demo está en construcción.")
                .font(.body)
                .foregroundStyle(AppPalette.textSecondary)
                .fixedSize(horizontal: false, vertical: true)
                .lineSpacing(4)

            Spacer(minLength: 0)

            Button(action: { dismiss() }) {
                Text("Volver al inicio")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
            }
            .buttonStyle(.borderedProminent)
            .tint(AppPalette.primary)
            .foregroundStyle(AppPalette.primaryOnPrimary)
            .accessibilityHint("Cierra esta pantalla y vuelve al inicio")
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .padding(.horizontal, 24)
        .padding(.top, 8)
        .padding(.bottom, 24)
        .background(AppPalette.canvas)
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
    }
}
