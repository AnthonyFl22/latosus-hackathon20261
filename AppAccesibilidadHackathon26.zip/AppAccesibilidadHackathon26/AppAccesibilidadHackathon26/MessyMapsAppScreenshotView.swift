//
//  MessyMapsAppScreenshotView.swift
//  AppAccesibilidadHackathon26
//
//  Mock deliberadamente poco usable para capturas: app de mapas genérica con
//  objetivos táctiles pequeños / mal espaciados y texto de resultados + legal
//  denso y confuso. No enlazada a AppRootView.
//

import SwiftUI

struct MessyMapsAppScreenshotView: View {
    var body: some View {
        VStack(spacing: 0) {
            messyAppChrome
            messySearchStrip
            messyFilterChips
            messyMapBlock
            messyResultsAndLegalScroll
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 0.88, green: 0.87, blue: 0.85))
    }

    // MARK: - Barra superior (iconos diminutos, poco aire)

    private var messyAppChrome: some View {
        HStack(spacing: 4) {
            Button(action: {}) {
                Image(systemName: "line.3.horizontal")
                    .font(.system(size: 11))
            }
            .frame(width: 26, height: 26)
            .buttonStyle(.plain)

            Text("GeoRuta+")
                .font(.system(size: 11, weight: .heavy))
                .foregroundStyle(Color(red: 0.2, green: 0.35, blue: 0.72))

            Spacer(minLength: 0)

            Button(action: {}) {
                Image(systemName: "bell")
                    .font(.system(size: 10))
            }
            .frame(width: 24, height: 24)
            Button(action: {}) {
                Image(systemName: "person.crop.circle")
                    .font(.system(size: 11))
            }
            .frame(width: 24, height: 24)
        }
        .padding(.horizontal, 6)
        .padding(.vertical, 4)
        .background(Color(red: 0.96, green: 0.95, blue: 0.93))
        .overlay(
            Rectangle()
                .frame(height: 1)
                .foregroundStyle(Color(red: 0.72, green: 0.68, blue: 0.62)),
            alignment: .bottom
        )
    }

    // MARK: - Búsqueda (campo bajo + botón minúsculo)

    private var messySearchStrip: some View {
        HStack(spacing: 3) {
            HStack(spacing: 4) {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 9))
                    .foregroundStyle(Color(red: 0.5, green: 0.48, blue: 0.46))
                Text("clínica medicina general sur")
                    .font(.system(size: 9))
                    .foregroundStyle(Color(red: 0.35, green: 0.33, blue: 0.38))
                    .lineLimit(1)
            }
            .padding(.vertical, 5)
            .padding(.horizontal, 6)
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 4))

            Button("×") {}
                .font(.system(size: 10, weight: .bold))
                .frame(width: 22, height: 22)
                .background(Color(red: 0.85, green: 0.82, blue: 0.78))
                .clipShape(Circle())
                .buttonStyle(.plain)
        }
        .padding(.horizontal, 5)
        .padding(.vertical, 3)
        .background(Color(red: 0.92, green: 0.9, blue: 0.86))
    }

    // MARK: - Filtros (chips pequeños, pegados)

    private var messyFilterChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 2) {
                chip("24h", on: false)
                chip("★>4", on: true)
                chip("APTA", on: false)
                chip("Párking", on: false)
                chip("SIN colas", on: false)
                chip("TZ:EM", on: false)
            }
            .padding(.horizontal, 4)
            .padding(.vertical, 2)
        }
        .background(Color(red: 0.9, green: 0.88, blue: 0.84))
    }

    private func chip(_ title: String, on: Bool) -> some View {
        Button(action: {}) {
            Text(title)
                .font(.system(size: 7, weight: .semibold))
                .padding(.vertical, 3)
                .padding(.horizontal, 5)
                .foregroundStyle(on ? Color.white : Color(red: 0.4, green: 0.38, blue: 0.42))
                .background(
                    on
                        ? Color(red: 0.15, green: 0.45, blue: 0.85)
                        : Color(red: 0.82, green: 0.8, blue: 0.76)
                )
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    // MARK: - Mapa falso (controles minúsculos, pins apiñados)

    private var messyMapBlock: some View {
        ZStack(alignment: .topLeading) {
            LinearGradient(
                colors: [
                    Color(red: 0.75, green: 0.82, blue: 0.7),
                    Color(red: 0.82, green: 0.78, blue: 0.72),
                    Color(red: 0.7, green: 0.76, blue: 0.85)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )

            // “Calles”
            Path { p in
                p.move(to: CGPoint(x: 20, y: 40))
                p.addLine(to: CGPoint(x: 280, y: 55))
                p.move(to: CGPoint(x: 100, y: 10))
                p.addLine(to: CGPoint(x: 85, y: 120))
            }
            .stroke(Color.white.opacity(0.35), lineWidth: 2)

            VStack {
                HStack {
                    Spacer()
                    VStack(spacing: 2) {
                        Button(action: {}) {
                            Image(systemName: "plus")
                                .font(.system(size: 9, weight: .bold))
                        }
                        .frame(width: 24, height: 22)
                        .background(Color.white.opacity(0.9))
                        .buttonStyle(.plain)
                        Button(action: {}) {
                            Image(systemName: "minus")
                                .font(.system(size: 9, weight: .bold))
                        }
                        .frame(width: 24, height: 22)
                        .background(Color.white.opacity(0.9))
                        .buttonStyle(.plain)
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 3))
                    .padding(.trailing, 4)
                    .padding(.top, 4)
                }
                Spacer()
            }

            // Pins muy juntos (área táctil ridícula)
            HStack(spacing: 1) {
                mapPinButton
                mapPinButton
                mapPinButton
                mapPinButton
            }
            .offset(x: 42, y: 36)

            HStack(spacing: 0) {
                mapPinButton
                mapPinButton
            }
            .offset(x: 150, y: 72)
        }
        .frame(height: 132)
        .clipped()
        .overlay(
            Rectangle()
                .strokeBorder(Color(red: 0.65, green: 0.62, blue: 0.58), lineWidth: 1)
        )
    }

    private var mapPinButton: some View {
        Button(action: {}) {
            Image(systemName: "mappin.circle.fill")
                .font(.system(size: 12))
                .foregroundStyle(Color.red.opacity(0.88))
        }
        .buttonStyle(.plain)
    }

    // MARK: - Resultados confusos + legal ilegible

    private var messyResultsAndLegalScroll: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 6) {
                Text("Resultados (14) · orden: relevancia¿? · últ. sync 14:02:07 UTC−?")
                    .font(.system(size: 8))
                    .foregroundStyle(Color(red: 0.45, green: 0.42, blue: 0.48))

                messyResultRow(
                    title: "CSur-MG-P2",
                    subtitle: "C/ Mayor 12-14 entlo. B (acceso tras.) · ref. ext. K-991",
                    meta: "ABI 08:30–13:45 / 16:00–19:15 exc. J ul. 2º y 4º · dist. ~0.8km lineal"
                )

                messyResultRow(
                    title: "PoliSalud Express™",
                    subtitle: "Av. Ronda sur s/n esq. PZ-7 (entr. parking -1 planta H)",
                    meta: "Colas ESTIM. variable · no garantiza MG mismo día · ver nota pie *"
                )

                messyResultRow(
                    title: "Centro Salud Zona C",
                    subtitle: "PZ Concepción 3 (edif. anexo mód. B2 código puerta #4821)",
                    meta: "Horario ref. ID-7b2 · sujeto a TZ Europe/Madrid (DST off-site calc)"
                )

                Text(
                    """
                    *AVISO LEGAL Y TRATAMIENTO DE DATOS DE UBICACIÓN (v.3.2 rev. 09/24): \
                    Los datos mostrados derivan de proveedores terceros y pueden no reflejar \
                    cierres temporales, obras, restricciones municipales ni disponibilidad real \
                    de cita. El cálculo de distancias es “en línea recta” salvo donde indique \
                    “ruta aprox.” (modo beta). Al continuar acepta CGU, política de cookies \
                    ampliada, LOPD-GDD y cesión a partners analíticos según cláusula 12.b. \
                    Revocatoria mediante formulario F-LOC-09 en plazo no inferior a 30 días \
                    hábiles. Para incidencias: soporte@ejemplo-maps.io (asunto REF+UUID).
                    """
                )
                .font(.system(size: 6.5))
                .foregroundStyle(Color(red: 0.52, green: 0.5, blue: 0.55))
                .lineSpacing(0)
                .fixedSize(horizontal: false, vertical: true)

                HStack(spacing: 3) {
                    Button("OK") {}
                        .font(.system(size: 8))
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color(red: 0.55, green: 0.53, blue: 0.58))
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 2))
                    Button("Más info") {}
                        .font(.system(size: 7))
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        .buttonStyle(.bordered)
                }
            }
            .padding(8)
        }
        .background(Color(red: 0.94, green: 0.93, blue: 0.9))
    }

    private func messyResultRow(title: String, subtitle: String, meta: String) -> some View {
        HStack(alignment: .top, spacing: 4) {
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 9, weight: .bold))
                    .foregroundStyle(Color(red: 0.18, green: 0.16, blue: 0.22))
                Text(subtitle)
                    .font(.system(size: 7.5))
                    .foregroundStyle(Color(red: 0.42, green: 0.4, blue: 0.46))
                    .fixedSize(horizontal: false, vertical: true)
                Text(meta)
                    .font(.system(size: 6.5))
                    .foregroundStyle(Color(red: 0.55, green: 0.52, blue: 0.5))
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
            VStack(spacing: 2) {
                Button("Ruta") {}
                    .font(.system(size: 7))
                    .padding(.horizontal, 5)
                    .padding(.vertical, 3)
                    .background(Color(red: 0.2, green: 0.5, blue: 0.95))
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 2))
                Button("⋯") {}
                    .font(.system(size: 9))
                    .frame(width: 22, height: 20)
                    .background(Color(red: 0.88, green: 0.86, blue: 0.82))
                    .clipShape(RoundedRectangle(cornerRadius: 2))
            }
            .buttonStyle(.plain)
        }
        .padding(5)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 4))
        .overlay(
            RoundedRectangle(cornerRadius: 4)
                .strokeBorder(Color(red: 0.8, green: 0.76, blue: 0.7), lineWidth: 0.5)
        )
    }
}

#Preview("Mapas poco accesible — captura") {
    MessyMapsAppScreenshotView()
}
