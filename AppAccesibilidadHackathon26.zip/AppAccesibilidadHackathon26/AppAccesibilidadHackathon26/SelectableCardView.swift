//
//  SelectableCardView.swift
//  AppAccesibilidadHackathon26
//

import SwiftUI

struct SelectableCardView: View {
    let icon: String
    let label: String
    var subtitle: String? = nil
    let isSelected: Bool
    let action: () -> Void

    @ScaledMetric(relativeTo: .title3) private var iconSize = 28.0

    private let cardRadius: CGFloat = 14

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: icon)
                    .font(.system(size: iconSize))
                    .foregroundStyle(isSelected ? AppPalette.primary : AppPalette.textSecondary)
                    .frame(width: iconSize + 8)

                VStack(alignment: .leading, spacing: 2) {
                    Text(label)
                        .font(.body.weight(.medium))
                        .foregroundStyle(AppPalette.textPrimary)

                    if let subtitle {
                        Text(subtitle)
                            .font(.footnote)
                            .foregroundStyle(AppPalette.textSecondary)
                    }
                }

                Spacer(minLength: 0)

                if isSelected {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.title3)
                        .foregroundStyle(AppPalette.primary)
                        .transition(.scale.combined(with: .opacity))
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(isSelected ? AppPalette.primaryMuted : AppPalette.surface)
            .clipShape(.rect(cornerRadius: cardRadius))
            .overlay(
                RoundedRectangle(cornerRadius: cardRadius)
                    .strokeBorder(
                        isSelected ? AppPalette.primary : AppPalette.border,
                        lineWidth: isSelected ? 2 : 1
                    )
            )
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isSelected)
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(isSelected ? [.isSelected] : [])
        .accessibilityHint(isSelected ? "Seleccionado" : "Toca para seleccionar")
    }
}

#Preview("Unselected") {
    SelectableCardView(
        icon: "textformat.size",
        label: "Texto pequeño",
        isSelected: false,
        action: {}
    )
    .padding()
    .background(AppPalette.canvas)
}

#Preview("Selected") {
    SelectableCardView(
        icon: "textformat.size",
        label: "Texto pequeño",
        isSelected: true,
        action: {}
    )
    .padding()
    .background(AppPalette.canvas)
}

#Preview("With Subtitle") {
    SelectableCardView(
        icon: "hand.point.up.left",
        label: "Paso a paso",
        subtitle: "Te guiamos en cada acción",
        isSelected: true,
        action: {}
    )
    .padding()
    .background(AppPalette.canvas)
}
