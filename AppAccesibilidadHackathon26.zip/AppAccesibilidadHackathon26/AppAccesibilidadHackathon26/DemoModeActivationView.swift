//
//  DemoModeActivationView.swift
//  AppAccesibilidadHackathon26
//

import SwiftUI

struct LargeModeToggleCard: View {
    let mode: DemoSupportMode
    let isOn: Bool
    let action: () -> Void

    @ScaledMetric(relativeTo: .title3) private var iconSize = 28.0

    private let cardRadius: CGFloat = 14

    private var statusLabel: String {
        isOn ? "Activado" : "Desactivado"
    }

    var body: some View {
        Button(action: action) {
            HStack(alignment: .top, spacing: 14) {
                Image(systemName: mode.icon)
                    .font(.system(size: iconSize))
                    .foregroundStyle(isOn ? AppPalette.primary : AppPalette.textSecondary)
                    .frame(width: iconSize + 8)

                VStack(alignment: .leading, spacing: 6) {
                    Text(mode.displayLabel)
                        .font(.body.weight(.semibold))
                        .foregroundStyle(AppPalette.textPrimary)

                    Text(mode.subtitle)
                        .font(.footnote)
                        .foregroundStyle(AppPalette.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .multilineTextAlignment(.leading)

                    Text(statusLabel)
                        .font(.caption.weight(.medium))
                        .foregroundStyle(isOn ? AppPalette.primary : AppPalette.textSecondary)
                }

                Spacer(minLength: 0)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(isOn ? AppPalette.primaryMuted : AppPalette.surface)
            .clipShape(.rect(cornerRadius: cardRadius))
            .overlay(
                RoundedRectangle(cornerRadius: cardRadius)
                    .strokeBorder(
                        isOn ? AppPalette.primary : AppPalette.border,
                        lineWidth: isOn ? 2 : 1
                    )
            )
        }
        .buttonStyle(.plain)
        .accessibilityLabel(mode.displayLabel)
        .accessibilityValue(statusLabel)
        .accessibilityHint("Toca para activar o desactivar esta ayuda")
    }
}

struct DemoModeActivationView: View {
    @Binding var enabledModes: Set<DemoSupportMode>
    let onContinue: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("¿Qué ayudas quieres activar desde ahora?")
                        .font(.title.bold())
                        .foregroundStyle(AppPalette.textPrimary)
                        .fixedSize(horizontal: false, vertical: true)
                        .accessibilityAddTraits(.isHeader)

                    Text("Puedes cambiar esto cuando quieras.")
                        .font(.body)
                        .foregroundStyle(AppPalette.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .lineSpacing(4)
                }

                VStack(spacing: 12) {
                    ForEach(DemoSupportMode.allCases) { mode in
                        LargeModeToggleCard(
                            mode: mode,
                            isOn: enabledModes.contains(mode)
                        ) {
                            toggleMode(mode)
                        }
                    }
                }
                .animation(.spring(response: 0.3, dampingFraction: 0.7), value: enabledModes)
            }
            .padding(.horizontal, 24)
            .padding(.top, 32)
            .padding(.bottom, 24)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            VStack(spacing: 12) {
                Button(action: onContinue) {
                    Text("Ver mi experiencia")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                }
                .buttonStyle(.borderedProminent)
                .tint(AppPalette.primary)
                .foregroundStyle(AppPalette.primaryOnPrimary)
                .accessibilityHint("Muestra un resumen y luego el inicio de la app")
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 16)
            .background(AppPalette.canvas)
        }
        .background(AppPalette.canvas)
    }

    private func toggleMode(_ mode: DemoSupportMode) {
        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
            if enabledModes.contains(mode) {
                enabledModes.remove(mode)
            } else {
                enabledModes.insert(mode)
            }
        }
    }
}

#Preview("Mode activation") {
    DemoModeActivationView(
        enabledModes: .constant(DemoSupportMode.elenaDefaults),
        onContinue: {}
    )
}
