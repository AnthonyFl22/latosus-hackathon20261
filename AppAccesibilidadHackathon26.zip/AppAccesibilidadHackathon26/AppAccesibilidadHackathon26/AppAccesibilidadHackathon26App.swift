//
//  AppAccesibilidadHackathon26App.swift
//  AppAccesibilidadHackathon26
//
//  Created by Kevin on 23/03/26.
//

import SwiftUI

@main
struct AppAccesibilidadHackathon26App: App {
    var body: some Scene {
        WindowGroup {
            AppRootView()
        }
    }
}
