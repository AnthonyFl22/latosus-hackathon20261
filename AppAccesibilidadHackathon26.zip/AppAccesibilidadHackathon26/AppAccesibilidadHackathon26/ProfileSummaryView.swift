//
//  ProfileSummaryView.swift
//  AppAccesibilidadHackathon26
//

import SwiftUI

struct ProfileSummaryView: View {
    let enabledModes: Set<DemoSupportMode>
    let onFinish: () -> Void

    @AppStorage("demoGuideMeEnabled") private var storedGuideMe = true
    @AppStorage("demoFocusEnabled") private var storedFocus = true
    @AppStorage("demoSimplifyEnabled") private var storedSimplify = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Tu experiencia está lista")
                        .font(.title.bold())
                        .foregroundStyle(AppPalette.textPrimary)
                        .fixedSize(horizontal: false, vertical: true)
                        .accessibilityAddTraits(.isHeader)

                    Text("Así te acompañaremos en la app.")
                        .font(.body)
                        .foregroundStyle(AppPalette.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .lineSpacing(4)
                }

                VStack(alignment: .leading, spacing: 12) {
                    summaryRow("Mostraremos texto claro")
                    summaryRow("Priorizaremos pasos importantes")
                    summaryRow("Activaremos ayuda guiada cuando la necesites")
                }
                .accessibilityElement(children: .combine)

                accessiblePreviewMiniature
            }
            .padding(.horizontal, 24)
            .padding(.top, 32)
            .padding(.bottom, 24)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            VStack(spacing: 12) {
                Button(action: completeOnboarding) {
                    Text("Ir al inicio")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                }
                .buttonStyle(.borderedProminent)
                .tint(AppPalette.primary)
                .foregroundStyle(AppPalette.primaryOnPrimary)
                .accessibilityHint("Guarda tu resumen y abre la pantalla de inicio")
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 16)
            .background(AppPalette.canvas)
        }
        .background(AppPalette.canvas)
    }

    private func summaryRow(_ text: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "checkmark.circle.fill")
                .font(.body)
                .foregroundStyle(AppPalette.success)
                .accessibilityHidden(true)

            Text(text)
                .font(.body)
                .foregroundStyle(AppPalette.textPrimary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var accessiblePreviewMiniature: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Vista de ejemplo con texto claro")
                .font(.subheadline.weight(.medium))
                .foregroundStyle(AppPalette.textSecondary)

            ZStack(alignment: .topLeading) {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(AppPalette.surfaceMuted)
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .strokeBorder(AppPalette.border, lineWidth: 1)
                    )

                VStack(alignment: .leading, spacing: 10) {
                    RoundedRectangle(cornerRadius: 4, style: .continuous)
                        .fill(AppPalette.primary.opacity(0.35))
                        .frame(width: 120, height: 10)
                        .accessibilityHidden(true)

                    Text("Paso siguiente")
                        .font(.title3.bold())
                        .foregroundStyle(AppPalette.textPrimary)

                    Text("Menos elementos a la vez")
                        .font(.subheadline)
                        .foregroundStyle(AppPalette.textSecondary)
                }
                .padding(16)
            }
            .frame(maxWidth: .infinity, minHeight: 140, alignment: .leading)
            .accessibilityHidden(true)
        }
    }

    private func completeOnboarding() {
        storedGuideMe = enabledModes.contains(.guideMe)
        storedFocus = enabledModes.contains(.focusMode)
        storedSimplify = enabledModes.contains(.simplifyThis)
        onFinish()
    }
}

#Preview {
    ProfileSummaryView(
        enabledModes: DemoSupportMode.elenaDefaults,
        onFinish: {}
    )
}
