//
//  OnboardingModels.swift
//  AppAccesibilidadHackathon26
//

import Foundation

// MARK: - Accessibility Difficulties

enum AccessibilityDifficulty: String, CaseIterable, Identifiable, Hashable {
    case smallText
    case tooMuchInfo
    case hardToFindButtons
    case longForms
    case confusingInstructions

    var id: String { rawValue }

    var displayLabel: String {
        switch self {
        case .smallText:            return "Texto pequeño"
        case .tooMuchInfo:          return "Demasiada información"
        case .hardToFindButtons:    return "Botones difíciles de encontrar"
        case .longForms:            return "Formularios largos"
        case .confusingInstructions: return "Instrucciones confusas"
        }
    }

    var icon: String {
        switch self {
        case .smallText:            return "textformat.size"
        case .tooMuchInfo:          return "rectangle.stack.fill"
        case .hardToFindButtons:    return "hand.tap"
        case .longForms:            return "doc.text.fill"
        case .confusingInstructions: return "questionmark.circle"
        }
    }

    /// Elena's hardcoded demo selections.
    static let elenaDefaults: Set<AccessibilityDifficulty> = [
        .smallText, .tooMuchInfo, .longForms
    ]
}

// MARK: - Interaction Style

enum InteractionStyle: String, CaseIterable, Identifiable, Hashable {
    case stepByStep
    case summaryView
    case voiceGuide
    case exploreAlone

    var id: String { rawValue }

    var displayLabel: String {
        switch self {
        case .stepByStep:    return "Paso a paso"
        case .summaryView:   return "Vista resumida"
        case .voiceGuide:    return "Guía por voz"
        case .exploreAlone:  return "Explorar por mi cuenta"
        }
    }

    var subtitle: String? {
        switch self {
        case .stepByStep:    return "Te guiamos en cada acción"
        case .summaryView:   return "Un resumen claro de lo importante"
        case .voiceGuide:    return "Instrucciones habladas"
        case .exploreAlone:  return "Sin guía, a tu ritmo"
        }
    }

    var icon: String {
        switch self {
        case .stepByStep:    return "hand.point.up.left"
        case .summaryView:   return "list.bullet.rectangle.portrait"
        case .voiceGuide:    return "speaker.wave.2"
        case .exploreAlone:  return "figure.walk"
        }
    }

    /// Elena's hardcoded demo selection.
    static let elenaDefault: InteractionStyle = .stepByStep
}

// MARK: - Demo support modes (onboarding screen 4)

enum DemoSupportMode: String, CaseIterable, Identifiable, Hashable {
    case focusMode
    case simplifyThis
    case guideMe

    var id: String { rawValue }

    var displayLabel: String {
        switch self {
        case .focusMode: return "Modo foco"
        case .simplifyThis: return "Simplificar"
        case .guideMe: return "Guíame"
        }
    }

    var subtitle: String {
        switch self {
        case .focusMode:
            return "Reduce el ruido y resalta lo importante"
        case .simplifyThis:
            return "Convierte contenido complejo en una vista más clara"
        case .guideMe:
            return "Te acompaña con instrucciones por voz"
        }
    }

    /// Short line shown on the home screen cards (screen 6); onboarding keeps `subtitle`.
    var homeCardSubtitle: String {
        switch self {
        case .focusMode:
            return "Resalto solo lo importante"
        case .simplifyThis:
            return "Convierto una pantalla compleja en algo más claro"
        case .guideMe:
            return "Te acompaño paso a paso"
        }
    }

    var icon: String {
        switch self {
        case .focusMode: return "scope"
        case .simplifyThis: return "rectangle.compress.vertical"
        case .guideMe: return "figure.walk.motion"
        }
    }

    /// Elena's demo defaults: Guide Me and Focus on; Simplify off but available.
    static let elenaDefaults: Set<DemoSupportMode> = [.guideMe, .focusMode]
}
