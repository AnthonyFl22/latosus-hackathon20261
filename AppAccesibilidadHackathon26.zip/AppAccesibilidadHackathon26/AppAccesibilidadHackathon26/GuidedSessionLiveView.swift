//
//  GuidedSessionLiveView.swift
//  AppAccesibilidadHackathon26
//

import AVFoundation
import Combine
import SwiftUI

final class GuidedSpeechController: NSObject, ObservableObject, AVSpeechSynthesizerDelegate {
    private let synthesizer = AVSpeechSynthesizer()

    /// When true, `speak` is a no-op and auto-speak is skipped.
    @Published var isMuted: Bool = false

    /// Slightly faster TTS for power users.
    @Published var fastRate: Bool = false

    private var rateFactor: Float {
        let base: Float = 0.88
        let boost: Float = fastRate ? 1.24 : 1.0
        return base * boost
    }

    override init() {
        super.init()
        synthesizer.delegate = self
    }

    /// Stops any current utterance and speaks `text` from the beginning (second tap restarts).
    func speak(_ text: String) {
        guard !isMuted else { return }
        synthesizer.stopSpeaking(at: .immediate)
        let utterance = AVSpeechUtterance(string: text)
        if let voice = AVSpeechSynthesisVoice.speechVoices().first(where: { $0.language == "es-ES" })
            ?? AVSpeechSynthesisVoice.speechVoices().first(where: { $0.language.hasPrefix("es") }) {
            utterance.voice = voice
        }
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate * rateFactor
        synthesizer.speak(utterance)
    }

    func stopSpeaking() {
        synthesizer.stopSpeaking(at: .immediate)
    }
}

struct GuidedSessionLiveView: View {
    @Environment(\.dismiss) private var dismiss

    /// When set, user can open `SimplifiedTaskView` on the same `NavigationStack` (Pantalla 10).
    var pathForSimplifiedLink: Binding<NavigationPath>? = nil

    @AppStorage("demoFocusEnabled") private var demoFocusEnabled = true
    @AppStorage("demoSimplifyEnabled") private var demoSimplifyEnabled = false

    @StateObject private var speech = GuidedSpeechController()

    @State private var stepIndex = 0
    @State private var focusEffectOn = true
    /// In-place simplified mock (secondary); prefer separate `SimplifiedTaskView` from the bubble menu.
    @State private var simplifiedLayoutOn = false
    @State private var bubbleExpanded = true

    private let steps = GuidedSessionStep.appointmentDemo

    private var currentStep: GuidedSessionStep {
        steps[min(max(stepIndex, 0), steps.count - 1)]
    }

    private var isLastStep: Bool {
        stepIndex >= steps.count - 1
    }

    private var focusActiveForMock: Bool {
        demoFocusEnabled && focusEffectOn
    }

    /// Ancho del panel: suficiente para textos y etiquetas sin truncar de más.
    private let assistantPanelMaxWidth: CGFloat = 356
    /// Tope de altura del contenido expandido; el resto hace scroll si hace falta.
    private let assistantExpandedMaxHeight: CGFloat = 320

    var body: some View {
        ZStack(alignment: .bottom) {
            VStack(spacing: 0) {
                DemoMobileBrowserChrome()
                AppointmentBookingMockContainer(
                    stepIndex: stepIndex,
                    isSimplified: demoSimplifyEnabled && simplifiedLayoutOn,
                    focusModeActive: focusActiveForMock,
                    scrollAnchor: currentStep.scrollAnchor
                )
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            HStack {
                Spacer(minLength: 12)
                assistantBubble
                    .frame(maxWidth: assistantPanelMaxWidth)
                Spacer(minLength: 12)
            }
            .padding(.bottom, 10)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(AppPalette.canvas)
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            if !speech.isMuted {
                speech.speak(currentStep.voiceScript)
            }
        }
        .onChange(of: stepIndex) { _, _ in
            speech.stopSpeaking()
            if !speech.isMuted {
                speech.speak(currentStep.voiceScript)
            }
        }
        .onChange(of: speech.isMuted) { _, muted in
            if muted {
                speech.stopSpeaking()
            } else {
                speech.speak(currentStep.voiceScript)
            }
        }
        .onDisappear {
            speech.stopSpeaking()
        }
    }

    private var assistantBubble: some View {
        VStack(alignment: .center, spacing: 0) {
            if bubbleExpanded {
                expandedBubbleContent
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            } else {
                collapsedBubbleChip
                    .transition(.opacity)
            }
        }
        .frame(maxWidth: .infinity)
        .animation(.spring(response: 0.32, dampingFraction: 0.86), value: bubbleExpanded)
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Asistente de la demo")
    }

    private var collapsedBubbleChip: some View {
        Button {
            bubbleExpanded = true
        } label: {
            HStack(alignment: .center, spacing: 10) {
                Image(systemName: "bubble.left.and.bubble.right.fill")
                    .font(.title3)
                    .foregroundStyle(AppPalette.primary)
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Paso \(stepIndex + 1) de \(steps.count)")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(AppPalette.textSecondary)
                    Text(currentStep.recommendedNextStep)
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(AppPalette.textPrimary)
                        .multilineTextAlignment(.leading)
                        .lineLimit(4)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Image(systemName: "chevron.up.circle.fill")
                    .font(.title3)
                    .symbolRenderingMode(.hierarchical)
                    .foregroundStyle(AppPalette.primary)
                    .accessibilityHidden(true)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 11)
            .frame(maxWidth: .infinity, alignment: .leading)
            .contentShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .background(AppPalette.surface)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .shadow(color: .black.opacity(0.08), radius: 10, y: 4)
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .strokeBorder(AppPalette.border, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Asistente minimizado. Paso \(stepIndex + 1) de \(steps.count). \(currentStep.recommendedNextStep)")
        .accessibilityHint("Abre el panel del asistente con todos los controles.")
    }

    private var expandedBubbleContent: some View {
        VStack(alignment: .leading, spacing: 0) {
            assistantPanelHeader

            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    stepContextCard
                    progressBlockCompact
                    navigationActionsSection
                    voiceAndFocusControlsSection

                    if demoSimplifyEnabled {
                        simplifiedOptionsMenu
                    }
                }
                .padding(.top, 10)
                .padding(.bottom, 4)
            }
            .frame(maxHeight: assistantExpandedMaxHeight)
            .scrollIndicators(.automatic)
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppPalette.surface)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .shadow(color: .black.opacity(0.1), radius: 12, y: 4)
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .strokeBorder(AppPalette.border, lineWidth: 1)
        )
    }

    private var assistantPanelHeader: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .center, spacing: 8) {
                Image(systemName: "person.wave.2.fill")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(AppPalette.primary)
                    .frame(width: 28, height: 28)
                    .background(AppPalette.primaryMuted.opacity(0.4))
                    .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                    .accessibilityHidden(true)
                Text("Asistente")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(AppPalette.textPrimary)
                Spacer(minLength: 4)
                Button {
                    bubbleExpanded = false
                } label: {
                    Image(systemName: "chevron.down.circle.fill")
                        .font(.title3)
                        .symbolRenderingMode(.hierarchical)
                        .foregroundStyle(AppPalette.textSecondary)
                        .frame(width: 36, height: 36)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Minimizar asistente")
                .accessibilityHint("Oculta el panel y deja solo un resumen pequeño.")
            }
            Rectangle()
                .fill(AppPalette.border)
                .frame(height: 1)
                .padding(.top, 8)
        }
    }

    private var stepContextCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(currentStep.screenSummary)
                .font(.subheadline)
                .foregroundStyle(AppPalette.textSecondary)
                .fixedSize(horizontal: false, vertical: true)

            Text(currentStep.recommendedNextStep)
                .font(.body.weight(.semibold))
                .foregroundStyle(AppPalette.primary)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(AppPalette.surfaceMuted)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .strokeBorder(AppPalette.border.opacity(0.8), lineWidth: 1)
        )
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Contexto. \(currentStep.screenSummary). Siguiente: \(currentStep.recommendedNextStep)")
    }

    private var progressBlockCompact: some View {
        VStack(alignment: .leading, spacing: 4) {
            ProgressView(value: Double(stepIndex + 1), total: Double(steps.count))
                .tint(AppPalette.primary)
                .scaleEffect(x: 1, y: 0.85, anchor: .center)
                .accessibilityLabel("Progreso del recorrido")
                .accessibilityValue("Paso \(stepIndex + 1) de \(steps.count)")
            Text("Paso \(stepIndex + 1) de \(steps.count)")
                .font(.caption.weight(.medium))
                .foregroundStyle(AppPalette.textSecondary)
                .accessibilityHidden(true)
        }
    }

    private var voiceAndFocusControlsSection: some View {
        VStack(spacing: 8) {
            HStack(alignment: .center, spacing: 8) {
                Button {
                    speech.speak(currentStep.voiceScript)
                } label: {
                    Image(systemName: "speaker.wave.2.fill")
                        .font(.body.weight(.semibold))
                        .frame(width: 44, height: 44)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.bordered)
                .tint(AppPalette.primary)
                .disabled(speech.isMuted)
                .accessibilityLabel("Escuchar este paso")
                .accessibilityHint(
                    speech.isMuted
                        ? "Activa el sonido para oír la guía."
                        : "Reproduce otra vez la voz de este paso."
                )

                Button {
                    speech.isMuted.toggle()
                } label: {
                    Label(
                        speech.isMuted ? "Activar sonido" : "Silenciar voz",
                        systemImage: speech.isMuted ? "speaker.fill" : "speaker.slash.fill"
                    )
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity, minHeight: 44)
                    .multilineTextAlignment(.center)
                }
                .buttonStyle(.bordered)
                .tint(AppPalette.primary)
                .accessibilityHint("Activa o desactiva la voz del asistente.")
            }

            HStack(alignment: .center, spacing: 8) {
                Button {
                    speech.fastRate.toggle()
                } label: {
                    Label(
                        speech.fastRate ? "Voz normal" : "Voz más rápida",
                        systemImage: "hare.fill"
                    )
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity, minHeight: 44)
                    .multilineTextAlignment(.center)
                }
                .buttonStyle(.bordered)
                .tint(AppPalette.primary)
                .accessibilityHint("Cambia la velocidad de la voz.")

                Toggle(isOn: $focusEffectOn) {
                    Label("Modo foco", systemImage: "scope")
                        .font(.subheadline.weight(.semibold))
                }
                .tint(AppPalette.primary)
                .disabled(!demoFocusEnabled)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.vertical, 4)
                .padding(.horizontal, 10)
                .background(AppPalette.surfaceMuted)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                .accessibilityHint(
                    demoFocusEnabled
                        ? "Atenúa lo secundario y resalta la zona del paso."
                        : "Activa Modo foco en personalización."
                )
            }
        }
    }

    private var navigationActionsSection: some View {
        VStack(spacing: 8) {
            Button {
                advanceStep()
            } label: {
                Label(
                    isLastStep ? "Fin del recorrido" : "Siguiente paso",
                    systemImage: "arrow.forward.circle.fill"
                )
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity, minHeight: 48)
                .multilineTextAlignment(.center)
            }
            .buttonStyle(.borderedProminent)
            .tint(AppPalette.primary)
            .foregroundStyle(AppPalette.primaryOnPrimary)
            .disabled(isLastStep)
            .accessibilityHint(
                isLastStep
                    ? "Has completado la demo de cita."
                    : "Avanza y actualiza la guía en el mismo formulario."
            )

            Button(role: .none) {
                speech.stopSpeaking()
                dismiss()
            } label: {
                Label("Salir del acompañamiento", systemImage: "xmark.circle.fill")
                    .font(.subheadline.weight(.medium))
                    .frame(maxWidth: .infinity, minHeight: 44)
                    .multilineTextAlignment(.center)
            }
            .buttonStyle(.bordered)
            .tint(AppPalette.textSecondary)
            .accessibilityHint("Cierra la sesión guiada.")
        }
    }

    private var simplifiedOptionsMenu: some View {
        Menu {
            if let pathBinding = pathForSimplifiedLink {
                Button {
                    speech.stopSpeaking()
                    pathBinding.wrappedValue.append(HomeRoute.simplify(fromGuidedSession: true))
                } label: {
                    Label("Abrir tarea en vista simplificada", systemImage: "rectangle.portrait.and.arrow.right")
                }
            }
            Toggle(isOn: $simplifiedLayoutOn) {
                Label("Formulario claro en esta pantalla", systemImage: "rectangle.compress.vertical")
            }
        } label: {
            Label("Más opciones", systemImage: "ellipsis.circle")
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity, minHeight: 44)
                .multilineTextAlignment(.center)
        }
        .buttonStyle(.bordered)
        .tint(AppPalette.primary)
        .accessibilityLabel("Más opciones del formulario")
        .accessibilityHint("Alternativas si el formulario abruma.")
    }

    private func advanceStep() {
        guard !isLastStep else { return }
        speech.stopSpeaking()
        stepIndex += 1
    }
}

#Preview("Guided live") {
    NavigationStack {
        GuidedSessionLiveView()
    }
}
