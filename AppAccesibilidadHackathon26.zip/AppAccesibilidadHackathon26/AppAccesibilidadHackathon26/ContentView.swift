//
//  ContentView.swift
//  AppAccesibilidadHackathon26
//
//  Created by Kevin on 23/03/26.
//

import SwiftUI

struct ContentView: View {
    var entryMode: MainEntryMode = .explore
    var onOpenPersonalization: () -> Void = {}

    @AppStorage("demoGuideMeEnabled") private var demoGuideMeEnabled = true
    @AppStorage("demoFocusEnabled") private var demoFocusEnabled = true
    @AppStorage("demoSimplifyEnabled") private var demoSimplifyEnabled = false

    @State private var path = NavigationPath()
    @State private var showProfileSheet = false

    private let homeCardModes: [DemoSupportMode] = [.guideMe, .simplifyThis, .focusMode]

    var body: some View {
        NavigationStack(path: $path) {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    headerBlock

                    VStack(spacing: 12) {
                        ForEach(homeCardModes) { mode in
                            let enabled = isModeEnabled(mode)
                            HomeModeEntryCard(
                                mode: mode,
                                isEnabled: enabled,
                                action: {
                                    guard enabled else { return }
                                    path.append(route(for: mode))
                                }
                            )
                        }
                    }
                    .accessibilityElement(children: .contain)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 24)
                .padding(.top, 24)
                .padding(.bottom, 8)
            }
            .background(AppPalette.canvas)
            .navigationTitle("Inicio")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Perfil") {
                        showProfileSheet = true
                    }
                    .accessibilityHint("Muestra un resumen de las ayudas activas")
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Ajustes") {
                        onOpenPersonalization()
                    }
                    .accessibilityHint(
                        entryMode == .explore
                            ? "Abre la personalización breve"
                            : "Vuelve a la personalización para cambiar tus respuestas"
                    )
                }
            }
            .navigationDestination(for: HomeRoute.self) { route in
                switch route {
                case .guidedSession:
                    GuidedSessionStartView(path: $path)
                case .guidedAppointmentDemo:
                    GuidedSessionLiveView(pathForSimplifiedLink: $path)
                case .simplify(let fromGuidedSession):
                    SimplifiedTaskView(fromGuidedSession: fromGuidedSession)
                case .focusMode:
                    HomeModePlaceholderView(route: route)
                }
            }
            .sheet(isPresented: $showProfileSheet) {
                HomeProfileSheet(
                    demoGuideMeEnabled: demoGuideMeEnabled,
                    demoFocusEnabled: demoFocusEnabled,
                    demoSimplifyEnabled: demoSimplifyEnabled,
                    onDismiss: { showProfileSheet = false }
                )
            }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                bottomActionBar
            }
        }
    }

    private var headerBlock: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Hola")
                .font(.title2.weight(.medium))
                .foregroundStyle(AppPalette.textSecondary)

            Text("¿En qué te ayudo hoy?")
                .font(.largeTitle.bold())
                .foregroundStyle(AppPalette.textPrimary)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)

            if entryMode == .explore {
                Text("Puedes personalizar cuando quieras desde Ajustes.")
                    .font(.body)
                    .foregroundStyle(AppPalette.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .lineSpacing(4)
            } else {
                Text("Tu experiencia sigue lo que elegiste.")
                    .font(.body)
                    .foregroundStyle(AppPalette.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .lineSpacing(4)
            }
        }
    }

    private var bottomActionBar: some View {
        VStack(spacing: 12) {
            Button(action: { path.append(HomeRoute.guidedSession) }) {
                Text("Comenzar sesión guiada")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
            }
            .buttonStyle(.borderedProminent)
            .tint(AppPalette.primary)
            .foregroundStyle(AppPalette.primaryOnPrimary)
            .disabled(!demoGuideMeEnabled)
            .accessibilityHint(
                demoGuideMeEnabled
                    ? "Abre la sesión guiada paso a paso"
                    : "Activa Guíame en personalización desde Ajustes."
            )

            Button(action: onOpenPersonalization) {
                Text(entryMode == .explore ? "Personalizar experiencia" : "Ajustar preferencias")
                    .font(.subheadline.weight(.medium))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
            }
            .buttonStyle(.plain)
            .foregroundStyle(AppPalette.primary)
            .accessibilityHint(
                entryMode == .explore
                    ? "Abre la personalización breve"
                    : "Vuelve a la personalización para cambiar tus respuestas"
            )
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 16)
        .background(AppPalette.canvas)
    }

    private func isModeEnabled(_ mode: DemoSupportMode) -> Bool {
        switch mode {
        case .guideMe: return demoGuideMeEnabled
        case .simplifyThis: return demoSimplifyEnabled
        case .focusMode: return demoFocusEnabled
        }
    }

    private func route(for mode: DemoSupportMode) -> HomeRoute {
        switch mode {
        case .guideMe: return .guidedSession
        case .simplifyThis: return .simplify(fromGuidedSession: false)
        case .focusMode: return .focusMode
        }
    }
}

// MARK: - Home mode card

private struct HomeModeEntryCard: View {
    let mode: DemoSupportMode
    let isEnabled: Bool
    let action: () -> Void

    @ScaledMetric(relativeTo: .title3) private var iconSize = 28.0

    private let cardRadius: CGFloat = 14

    var body: some View {
        Button(action: action) {
            HStack(alignment: .top, spacing: 14) {
                Image(systemName: mode.icon)
                    .font(.system(size: iconSize))
                    .foregroundStyle(isEnabled ? AppPalette.primary : AppPalette.textSecondary)
                    .frame(width: iconSize + 8)

                VStack(alignment: .leading, spacing: 4) {
                    Text(mode.displayLabel)
                        .font(.body.weight(.semibold))
                        .foregroundStyle(isEnabled ? AppPalette.textPrimary : AppPalette.textSecondary)

                    Text(mode.homeCardSubtitle)
                        .font(.footnote)
                        .foregroundStyle(AppPalette.textSecondary)
                        .multilineTextAlignment(.leading)
                        .fixedSize(horizontal: false, vertical: true)
                }

                Spacer(minLength: 0)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(isEnabled ? AppPalette.surface : AppPalette.surfaceMuted)
            .clipShape(RoundedRectangle(cornerRadius: cardRadius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: cardRadius, style: .continuous)
                    .strokeBorder(
                        isEnabled ? AppPalette.border : AppPalette.border.opacity(0.55),
                        lineWidth: 1
                    )
            )
        }
        .buttonStyle(.plain)
        .disabled(!isEnabled)
        .accessibilityHint(
            isEnabled
                ? "Abre este modo de ayuda"
                : "Activa esta ayuda en personalización desde Ajustes."
        )
    }
}

// MARK: - Profile sheet

private struct HomeProfileSheet: View {
    let demoGuideMeEnabled: Bool
    let demoFocusEnabled: Bool
    let demoSimplifyEnabled: Bool
    let onDismiss: () -> Void

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("Así tienes configuradas las ayudas en esta demo.")
                        .font(.body)
                        .foregroundStyle(AppPalette.textSecondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .lineSpacing(4)

                    VStack(spacing: 12) {
                        profileRow(label: "Guíame", isOn: demoGuideMeEnabled)
                        profileRow(label: "Modo foco", isOn: demoFocusEnabled)
                        profileRow(label: "Simplificar", isOn: demoSimplifyEnabled)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 24)
                .padding(.top, 24)
                .padding(.bottom, 24)
            }
            .background(AppPalette.canvas)
            .navigationTitle("Perfil")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Cerrar", action: onDismiss)
                }
            }
        }
        .presentationDetents([.medium])
    }

    private func profileRow(label: String, isOn: Bool) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 12) {
            Text(label)
                .font(.body.weight(.medium))
                .foregroundStyle(AppPalette.textPrimary)

            Spacer(minLength: 0)

            Text(isOn ? "Activada" : "Desactivada")
                .font(.subheadline.weight(.medium))
                .foregroundStyle(isOn ? AppPalette.primary : AppPalette.textSecondary)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppPalette.surface)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(AppPalette.border, lineWidth: 1)
        )
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(label), \(isOn ? "activada" : "desactivada")")
    }
}

#Preview {
    AppRootView()
}
