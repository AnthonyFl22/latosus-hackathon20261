//
//  SimplifiedTaskView.swift
//  AppAccesibilidadHackathon26
//

import SwiftUI

private enum SimplifiedAppointmentStep: Int, CaseIterable, Identifiable {
    case pickDate
    case pickTime
    case confirm

    var id: Int { rawValue }

    var title: String {
        switch self {
        case .pickDate: return "Elegir fecha"
        case .pickTime: return "Elegir horario"
        case .confirm: return "Confirmar cita"
        }
    }

    var icon: String {
        switch self {
        case .pickDate: return "calendar"
        case .pickTime: return "clock"
        case .confirm: return "checkmark.seal"
        }
    }
}

private enum StepVisualState {
    case pending
    case current
    case completed
}

/// Voice lines for Pantalla 10 — same assist flow as Pantalla 9 (Escuchar).
private enum SimplifiedTaskVoiceScript {
    static let perStep: [String] = [
        "Estamos en la versión simplificada. Primero elige la fecha de tu cita. Aquí solo ves tres pasos grandes, sin el resto de la página.",
        "Ahora elige el horario que prefieras.",
        "Último paso: confirma la cita. En una app real, aquí guardarías la reserva."
    ]

    static let allDone =
        "Has repasado los tres pasos de esta demo. Puedes usar Salir para volver a la pantalla anterior."
}

struct SimplifiedTaskView: View {
    @Environment(\.dismiss) private var dismiss

    /// When true, user arrived from `GuidedSessionLiveView`; hints reference returning to pantalla 9.
    var fromGuidedSession: Bool = false

    @StateObject private var speech = GuidedSpeechController()

    /// Index 0...2 = active step; 3 = flow finished (all steps done).
    @State private var stage: Int = 0

    private let steps = SimplifiedAppointmentStep.allCases

    private var flowFinished: Bool {
        stage >= steps.count
    }

    private var currentVoiceLine: String {
        if flowFinished {
            return SimplifiedTaskVoiceScript.allDone
        }
        let idx = min(max(stage, 0), SimplifiedTaskVoiceScript.perStep.count - 1)
        return SimplifiedTaskVoiceScript.perStep[idx]
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                headerBlock

                if flowFinished {
                    completionBlock
                }

                VStack(spacing: 12) {
                    ForEach(Array(steps.enumerated()), id: \.element.id) { index, step in
                        simplifiedStepCard(step: step, index: index)
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 24)
            .padding(.top, 20)
            .padding(.bottom, 8)
        }
        .background(AppPalette.canvas)
        .navigationTitle("Simplificar")
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaInset(edge: .bottom, spacing: 0) {
            assistedBottomBar
        }
        .onDisappear {
            speech.stopSpeaking()
        }
    }

    private var headerBlock: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Versión simplificada")
                .font(.largeTitle.bold())
                .foregroundStyle(AppPalette.textPrimary)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)

            Text("Te muestro solo lo necesario para completar esta tarea")
                .font(.body)
                .foregroundStyle(AppPalette.textSecondary)
                .fixedSize(horizontal: false, vertical: true)
                .lineSpacing(4)

            if fromGuidedSession {
                Text("Abajo tienes la misma ayuda que en la sesión guiada: escuchar, avanzar y salir.")
                    .font(.footnote)
                    .foregroundStyle(AppPalette.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var completionBlock: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "checkmark.circle.fill")
                .font(.title2)
                .foregroundStyle(AppPalette.success)
                .accessibilityHidden(true)
            Text("En la demo, la cita quedaría lista con estos tres pasos. No se guarda nada real.")
                .font(.subheadline)
                .foregroundStyle(AppPalette.textPrimary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppPalette.primaryMuted)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(AppPalette.border, lineWidth: 1)
        )
        .accessibilityElement(children: .combine)
    }

    private func simplifiedStepCard(step: SimplifiedAppointmentStep, index: Int) -> some View {
        let state = visualState(for: index)
        return HStack(alignment: .top, spacing: 14) {
            Image(systemName: statusIcon(for: state, stepIcon: step.icon))
                .font(.title2)
                .foregroundStyle(iconColor(for: state))
                .frame(width: 36, alignment: .center)
                .accessibilityHidden(true)

            VStack(alignment: .leading, spacing: 6) {
                HStack {
                    Text(step.title)
                        .font(.body.weight(.semibold))
                        .foregroundStyle(AppPalette.textPrimary)
                    if state == .current {
                        Text("Paso actual")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(AppPalette.primary)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(AppPalette.primaryMuted)
                            .clipShape(Capsule())
                    }
                }
                Text(statusCaption(for: state))
                    .font(.footnote)
                    .foregroundStyle(AppPalette.textSecondary)
            }
            Spacer(minLength: 0)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(cardBackground(for: state))
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .strokeBorder(borderColor(for: state), lineWidth: state == .current ? 2 : 1)
        )
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(step.title). \(accessibilityStatusPhrase(for: state))")
    }

    private func visualState(for index: Int) -> StepVisualState {
        if flowFinished { return .completed }
        if index < stage { return .completed }
        if index == stage { return .current }
        return .pending
    }

    private func statusIcon(for state: StepVisualState, stepIcon: String) -> String {
        switch state {
        case .completed: return "checkmark.circle.fill"
        case .current: return stepIcon
        case .pending: return "circle"
        }
    }

    private func iconColor(for state: StepVisualState) -> Color {
        switch state {
        case .completed: return AppPalette.success
        case .current: return AppPalette.primary
        case .pending: return AppPalette.textSecondary
        }
    }

    private func cardBackground(for state: StepVisualState) -> Color {
        switch state {
        case .current: return AppPalette.primaryMuted
        case .completed, .pending: return AppPalette.surface
        }
    }

    private func borderColor(for state: StepVisualState) -> Color {
        switch state {
        case .current: return AppPalette.primary
        case .completed: return AppPalette.border
        case .pending: return AppPalette.border.opacity(0.7)
        }
    }

    private func statusCaption(for state: StepVisualState) -> String {
        switch state {
        case .pending: return "Pendiente"
        case .current:
            return "Usa Escuchar y Siguiente paso abajo, igual que en la sesión guiada. Es una demo sin cita real."
        case .completed: return "Listo en esta versión simplificada"
        }
    }

    private func accessibilityStatusPhrase(for state: StepVisualState) -> String {
        switch state {
        case .pending: return "Pendiente"
        case .current: return "Paso actual"
        case .completed: return "Completado"
        }
    }

    /// Same three actions as `GuidedSessionLiveView` (Pantalla 9).
    private var assistedBottomBar: some View {
        VStack(spacing: 10) {
            Button {
                speech.speak(currentVoiceLine)
            } label: {
                Label("Escuchar", systemImage: "speaker.wave.2.fill")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
            }
            .buttonStyle(.borderedProminent)
            .tint(AppPalette.primary)
            .foregroundStyle(AppPalette.primaryOnPrimary)
            .accessibilityHint("Lee en voz alta la guía del paso actual en esta vista simplificada. Si ya está leyendo, vuelve a empezar.")

            Button {
                guard !flowFinished else { return }
                speech.stopSpeaking()
                stage += 1
            } label: {
                Label("Siguiente paso", systemImage: "arrow.forward.circle.fill")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
            }
            .buttonStyle(.bordered)
            .tint(AppPalette.primary)
            .disabled(flowFinished)
            .accessibilityHint(
                flowFinished
                    ? "Has completado los tres pasos de esta vista."
                    : "Avanza al siguiente paso y detiene la voz si estaba sonando."
            )

            Button(role: .none) {
                speech.stopSpeaking()
                dismiss()
            } label: {
                Label("Salir", systemImage: "xmark.circle.fill")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
            }
            .buttonStyle(.bordered)
            .tint(AppPalette.textSecondary)
            .accessibilityHint(salirAccessibilityHint)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 16)
        .background(AppPalette.canvas)
    }

    private var salirAccessibilityHint: String {
        if fromGuidedSession {
            return "Cierra la vista simplificada y vuelve a la sesión guiada con la pantalla compartida y el panel del asistente."
        }
        return "Cierra esta pantalla y vuelve al inicio."
    }
}

#Preview("Desde inicio") {
    NavigationStack {
        SimplifiedTaskView(fromGuidedSession: false)
    }
}

#Preview("Desde sesión guiada") {
    NavigationStack {
        SimplifiedTaskView(fromGuidedSession: true)
    }
}
